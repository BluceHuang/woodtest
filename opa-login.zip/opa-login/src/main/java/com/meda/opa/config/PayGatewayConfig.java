package com.meda.opa.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 支付网关配置类
 *
 * @author Huangxiaodi
 * @date 2018/11/14
 */
@Component
public class PayGatewayConfig {

    /**
     * appType为1的获取预支付id URL
     */
    public static String PAY_GATEWAY_GET_PREPAY_ID_APP1_URL;

    /**
     * 测试模式下获取预支付id URL
     */
    public static String PAY_GATEWAY_GET_PREPAY_ID_TEST_URL;

    /**
     * v2的获取预支付id URL
     */
    public static String PAY_GATEWAY_GET_PREPAY_ID_V2_URL;

    /**
     * v3的获取预支付id URL
     */
    public static String PAY_GATEWAY_GET_PREPAY_ID_V3_URL;

    /**
     * 订单数据加密盐值
     */
    public static String SHA1_TOKEN;

    @Value("${pay_gateway.get_prepay_id_app1.url}")
    public void setPayGatewayGetPrepayIdApp1Url(String payGatewayGetPrepayIdApp1Url) {
        PAY_GATEWAY_GET_PREPAY_ID_APP1_URL = payGatewayGetPrepayIdApp1Url;
    }

    @Value("${pay_gateway.get_prepay_id_test.url}")
    public void setPayGatewayGetPrepayIdTestUrl(String payGatewayGetPrepayIdTestUrl) {
        PAY_GATEWAY_GET_PREPAY_ID_TEST_URL = payGatewayGetPrepayIdTestUrl;
    }

    @Value("${pay_gateway.get_prepay_id_v2.url}")
    public void setPayGatewayGetPrepayIdV2Url(String payGatewayGetPrepayIdV2Url) {
        PAY_GATEWAY_GET_PREPAY_ID_V2_URL = payGatewayGetPrepayIdV2Url;
    }

    @Value("${pay_gateway.get_prepay_id_v3.url}")
    public void setPayGatewayGetPrepayIdV3Url(String payGatewayGetPrepayIdV3Url) {
        PAY_GATEWAY_GET_PREPAY_ID_V3_URL = payGatewayGetPrepayIdV3Url;
    }

    @Value("${sha1_token}")
    public void setSha1Token(String sha1Token) {
        SHA1_TOKEN = sha1Token;
    }
}
