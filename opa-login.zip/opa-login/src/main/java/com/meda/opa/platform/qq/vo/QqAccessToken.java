package com.meda.opa.platform.qq.vo;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * @author Huangxiaodi
 * @date 2018/11/21
 */
public class QqAccessToken {

    @JSONField(name = "access_token")
    private String accessToken;

    private int expire;

    @JSONField(name = "errcode")
    private int errCode;

    @JSONField(name = "errmsg")
    private String errMsg;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public int getExpire() {
        return expire;
    }

    public void setExpire(int expire) {
        this.expire = expire;
    }

    public int getErrCode() {
        return errCode;
    }

    public void setErrCode(int errCode) {
        this.errCode = errCode;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

    @Override
    public String toString() {
        return "QqAccessToken{" +
                "accessToken='" + accessToken + '\'' +
                ", expire=" + expire +
                ", errCode=" + errCode +
                ", errMsg='" + errMsg + '\'' +
                '}';
    }
}
