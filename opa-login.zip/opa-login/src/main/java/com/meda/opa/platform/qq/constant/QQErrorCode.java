package com.meda.opa.platform.qq.constant;

/**
 * QQ错误响应码
 *
 * @author Huangxiaodi
 * @date 2018/11/26
 */
public class QQErrorCode {

    /**
     * 0:成功
     */
    public static final int SUCCESS = 0;
}
