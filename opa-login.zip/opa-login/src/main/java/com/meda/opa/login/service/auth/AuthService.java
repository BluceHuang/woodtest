package com.meda.opa.login.service.auth;

import com.meda.opa.login.dto.LoginOrRegisterResult;
import com.meda.opa.login.vo.ProductInfo;

/**
 * 微信公众号用户授权接口
 *
 * @author yuanzipeng
 * @date 2018/8/31.
 */
public interface AuthService {

    /**
     * 构建第三方网页授权url
     *
     * @param productInfo 产品服务器的相关参数
     * @return
     */
    String getThirdPartyAuthoriseUrl(ProductInfo productInfo);

    /**
     * 用户中心授权
     *
     * @param code 第三方网页授权回调本系统uri时带回的code
     * @param arg  扫描二维码传回的参数包括了mid（机器ID）、type（产品的类型编号）、srv_uri（产品服务URI）等，用,分隔
     * @return
     */
    LoginOrRegisterResult getAuth(String code, String arg);
}
