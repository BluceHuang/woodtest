package com.meda.opa.common.constant;

/**
 * 支付宝常量
 *
 * @author Huangxiaodi
 * @date 2018/11/23
 */
public class AlipayConstant {

    /**
     * 支付宝性别【注意】只有is_certified为T的时候才有意义，否则不保证准确性.
     * 性别（F：女性；M：男性）。
     */
    public static final String SEX_MALE = "m";
    /**
     * 支付宝性别【注意】只有is_certified为T的时候才有意义，否则不保证准确性.
     * 性别（F：女性；M：男性）。
     */
    public static final String SEX_FEMALE = "f";
}
