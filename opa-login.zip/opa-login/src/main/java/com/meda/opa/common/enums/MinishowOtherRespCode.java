package com.meda.opa.common.enums;

/**
 * minishow补充服务接口响应码枚举类
 *
 * @author Huangxiaodi
 * @date 2018/10/22
 */
public enum MinishowOtherRespCode {
    /**
     * 0: 成功
     */
    SUCCESS(0, "成功");

    private int resCode;

    private String msg;

    MinishowOtherRespCode(int resCode, String msg) {
        this.resCode = resCode;
        this.msg = msg;
    }

    public int getResCode() {
        return resCode;
    }

    public void setResCode(int resCode) {
        this.resCode = resCode;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
