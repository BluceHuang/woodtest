package com.meda.opa.login.vo;

/**
 * 用户中心注册接口请求info节点对应实体
 *
 * @author Huangxiaodi
 * @date 2018/11/21
 */
public class EmptyInfo {
    @Override
    public String toString() {
        return "EmptyInfo{}";
    }
}
