package com.meda.opa.pay.service;


import com.meda.opa.pay.vo.machine.ResponseInQueryMachineInfo;

/**
 * 机器服务接口
 *
 * @author Huangxiaodi
 * @date 2018/10/24
 */
public interface MachineService {

    /**
     * 根据机器id查询机器信息
     *
     * @param mid 机器id
     * @return
     */
    ResponseInQueryMachineInfo getByMid(String mid);
}
