package com.meda.opa.login.controller.auth;

import com.meda.opa.common.constant.HttpConstant;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.common.constant.QRCodeConstant;
import com.meda.opa.common.enums.ResultCode;
import com.meda.opa.common.util.LogUtils;
import com.meda.opa.common.util.RedisUtils;
import com.meda.opa.config.MinishowConfig;
import com.meda.opa.login.dto.LoginOrRegisterResult;
import com.meda.opa.login.vo.ProductInfo;
import com.meda.opa.login.service.auth.AuthService;
import com.meda.opa.pay.service.PackageService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletRequest;

/**
 * 微信公众号用户授权功能
 *
 * @author Huangxiaodi
 * @date 2018/11/21.
 */
@RestController
@RequestMapping("auth")
public class AuthController {

    private static Logger log = LoggerFactory.getLogger(AuthController.class);

    @Autowired
    private AuthService qqAuthService;

    @Autowired
    private AuthService aliPayAuthService;

    @Autowired
    private AuthService weChatAuthService;

    @Autowired
    private PackageService packageService;

    @Autowired
    private RedisUtils redisUtils;

    /**
     * 二维码扫描登录接口
     *
     * @param productInfo 产品服务器的相关参数
     * @param req         服务请求
     * @return 微信授权登录接口
     */
    @GetMapping("login")
    public RedirectView login(@Validated ProductInfo productInfo, HttpServletRequest req) {
        String userAgent = req.getHeader(HttpConstant.HEADER_USER_AGENT);
        if (StringUtils.isBlank(userAgent)) {
            return new RedirectView(MinishowConfig.INVALID_USER_AGENT_ERROR_URL);
        }

        AuthService authService = getServiceByUserAgent(userAgent);
        if (authService == null) {
            return new RedirectView(MinishowConfig.INVALID_USER_AGENT_ERROR_URL);
        }

        String url = authService.getThirdPartyAuthoriseUrl(productInfo);
        LogUtils.logInfo(log, "扫码登录重定向", LogConstant.RES_SUCCESS, "", 0, Integer.parseInt(productInfo.getMid()), "扫码登录重定向【成功】，重定向url为：" + url);
        return new RedirectView(url);
    }

    /**
     * 根据请求头的userAgent决定使用哪个实现类
     *
     * @param userAgent
     * @return
     */
    private AuthService getServiceByUserAgent(String userAgent) {
        if (userAgent.contains(QRCodeConstant.USER_AGENT_WECHAT)) {
            return weChatAuthService;
        } else if (userAgent.contains(QRCodeConstant.USER_AGENT_ALIPAY)) {
            return aliPayAuthService;
        } else if (userAgent.contains(QRCodeConstant.USER_AGENT_QQ)) {
            return qqAuthService;
        } else {
            return null;
        }
    }

    /**
     * 微信第三方网页授权回调uri，实现用户中心注册登录与点歌页面跳转功能
     *
     * @param code 第三方网页授权回调本系统uri时带回的code
     * @param arg  扫描二维码传回的参数包括了mid（机器ID）、type（产品的类型编号）、srv_uri（回调URI）等，用,分隔
     * @return 点歌页面
     */
    @HystrixCommand(fallbackMethod = "authError")
    @GetMapping("getWeChatAuth")
    public RedirectView getAuth(@RequestParam(value = "code", required = true) String code, @RequestParam(value = "arg", required = true) String arg) {
        LoginOrRegisterResult result = weChatAuthService.getAuth(code, arg);
        String finalUrl = getFinalUrl(result);
        return new RedirectView(finalUrl);
    }

    /**
     * 支付宝第三方网页授权回调uri，实现用户中心注册登录与点歌页面跳转功能
     *
     * @param code 第三方网页授权回调本系统uri时带回的code
     * @param arg  扫描二维码传回的参数包括了mid（机器ID）、type（产品的类型编号）、srv_uri（回调URI）等，用,分隔
     * @return 点歌页面
     */
    @HystrixCommand(fallbackMethod = "authError", commandKey = "getAliPayAuth")
    @GetMapping("getAliPayAuth")
    public RedirectView getAliPayAuth(@RequestParam(value = "auth_code", required = true) String code,
                                      @RequestParam(value = "arg", required = true) String arg) throws Exception {
        LoginOrRegisterResult result = aliPayAuthService.getAuth(code, arg);
        String finalUrl = getFinalUrl(result);
        return new RedirectView(finalUrl);
    }

    /**
     * QQ第三方网页授权回调uri，实现用户中心注册登录与点歌页面跳转功能
     *
     * @param code 第三方网页授权回调本系统uri时带回的code
     * @param arg  扫描二维码传回的参数包括了mid（机器ID）、type（产品的类型编号）、srv_uri（回调URI）等，用,分隔
     * @return 点歌页面
     */
    @HystrixCommand(fallbackMethod = "authError")
    @GetMapping("getQQAuth")
    public RedirectView getQQAuth(@RequestParam(value = "code", required = true) String code,
                                  @RequestParam(value = "arg", required = true) String arg) throws Exception {
        LoginOrRegisterResult result;
        if (redisUtils.chekcExistByStringKey(code)) {
            result = new LoginOrRegisterResult(ResultCode.QQ_AUTH_MULTI_REDIRECT.getCode());
        } else {
            redisUtils.setStringAndExpire(code, 300, "");
            result = qqAuthService.getAuth(code, arg);
        }
        String finalUrl = getFinalUrl(result);
        return new RedirectView(finalUrl);
    }

    private String getFinalUrl(LoginOrRegisterResult result) {
        String finalUrl;
        if (!ResultCode.SUCCESS.getCode().equals(result.getResponseCode())) {
            finalUrl = MinishowConfig.LOGIN_FAIL_URL.replace("CODE", result.getResponseCode());
        } else {
            finalUrl = packageService.buildPackageBuyRedirectUrl(result.getUid(), String.valueOf(result.getUno()),
                    String.valueOf(result.getMid()), result.getUnionId(), result.getCouponId());
        }
        return finalUrl;
    }

    /**
     * 扫码登录服务降级方法
     * @param code
     * @param arg
     * @return
     */
    public RedirectView authError(String code, String arg) {
        return new RedirectView(MinishowConfig.SYSTEM_BUSY_URL);
    }
}
