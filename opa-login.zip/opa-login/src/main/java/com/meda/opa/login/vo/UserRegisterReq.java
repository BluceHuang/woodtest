package com.meda.opa.login.vo;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * 用户中心注册登录接口请求vo
 *
 * @author Huangxiaodi
 * @date 2018/11/21
 */
public class UserRegisterReq {

    private String type;

    @JSONField(name = "loginid")
    private String loginId;

    private String pwd;

    private ProductInfo product;

    private BaseUserInfo usrinfo;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public ProductInfo getProduct() {
        return product;
    }

    public void setProduct(ProductInfo product) {
        this.product = product;
    }

    public BaseUserInfo getUsrinfo() {
        return usrinfo;
    }

    public void setUsrinfo(BaseUserInfo usrinfo) {
        this.usrinfo = usrinfo;
    }

    @Override
    public String toString() {
        return "UserRegisterReq{" +
                "type='" + type + '\'' +
                ", loginId='" + loginId + '\'' +
                ", pwd='" + pwd + '\'' +
                ", product=" + product +
                ", usrinfo=" + usrinfo +
                '}';
    }

    public static class BaseUserInfo {
        protected String city;

        protected String country;

        protected String ex;

        @JSONField(name = "image_url")
        protected String imageUrl;

        protected String name;

        protected String province;

        protected String sex;

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public String getEx() {
            return ex;
        }

        public void setEx(String ex) {
            this.ex = ex;
        }

        public String getImageUrl() {
            return imageUrl;
        }

        public void setImageUrl(String imageUrl) {
            this.imageUrl = imageUrl;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getProvince() {
            return province;
        }

        public void setProvince(String province) {
            this.province = province;
        }

        public String getSex() {
            return sex;
        }

        public void setSex(String sex) {
            this.sex = sex;
        }
    }

    public static class WeChatUserInfo extends BaseUserInfo {

        @JSONField(name = "bind_wx")
        private String bindWx;

        public String getBindWx() {
            return bindWx;
        }

        public void setBindWx(String bindWx) {
            this.bindWx = bindWx;
        }

        @Override
        public String toString() {
            return "BaseUserInfo{" +
                    "bindWx='" + bindWx + '\'' +
                    "city='" + city + '\'' +
                    ", country='" + country + '\'' +
                    ", ex='" + ex + '\'' +
                    ", imageUrl='" + imageUrl + '\'' +
                    ", name='" + name + '\'' +
                    ", province='" + province + '\'' +
                    ", sex='" + sex + '\'' +
                    '}';
        }
    }

    public static class QQUserInfo extends BaseUserInfo {

        @JSONField(name = "bind_qq")
        private String bindQQ;

        public String getBindQQ() {
            return bindQQ;
        }

        public void setBindQQ(String bindQQ) {
            this.bindQQ = bindQQ;
        }

        @Override
        public String toString() {
            return "BaseUserInfo{" +
                    "bindQQ='" + bindQQ + '\'' +
                    "city='" + city + '\'' +
                    ", country='" + country + '\'' +
                    ", ex='" + ex + '\'' +
                    ", imageUrl='" + imageUrl + '\'' +
                    ", name='" + name + '\'' +
                    ", province='" + province + '\'' +
                    ", sex='" + sex + '\'' +
                    '}';
        }
    }

    public static class AlipayUserInfo extends BaseUserInfo {

        @JSONField(name = "bind_zfb")
        private String bindZfb;

        public String getBindZfb() {
            return bindZfb;
        }

        public void setBindZfb(String bindZfb) {
            this.bindZfb = bindZfb;
        }

        @Override
        public String toString() {
            return "BaseUserInfo{" +
                    "bindZfb='" + bindZfb + '\'' +
                    "city='" + city + '\'' +
                    ", country='" + country + '\'' +
                    ", ex='" + ex + '\'' +
                    ", imageUrl='" + imageUrl + '\'' +
                    ", name='" + name + '\'' +
                    ", province='" + province + '\'' +
                    ", sex='" + sex + '\'' +
                    '}';
        }
    }

}
