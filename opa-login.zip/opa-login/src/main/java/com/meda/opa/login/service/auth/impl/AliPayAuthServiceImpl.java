package com.meda.opa.login.service.auth.impl;

import com.alipay.api.response.AlipaySystemOauthTokenResponse;
import com.alipay.api.response.AlipayUserInfoShareResponse;
import com.meda.opa.common.constant.AlipayConstant;
import com.meda.opa.common.constant.CharactersConstant;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.common.constant.UserCenterConstant;
import com.meda.opa.common.enums.ResultCode;
import com.meda.opa.common.util.LogUtils;
import com.meda.opa.common.util.RedisUtils;
import com.meda.opa.config.AlipayConfig;
import com.meda.opa.login.dto.LoginOrRegisterResult;
import com.meda.opa.login.vo.EmptyInfo;
import com.meda.opa.login.vo.ProductInfo;
import com.meda.opa.login.vo.UserRegisterReq;
import com.meda.opa.platform.alipay.service.AliPayService;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * 支付宝用户授权登录服务实现类
 *
 * @author Huangxiaodi
 * @date 2018/11/21.
 */
@Service("aliPayAuthService")
public class AliPayAuthServiceImpl extends AbstractAuthServiceImpl {

    private static Logger log = LoggerFactory.getLogger(AliPayAuthServiceImpl.class);

    private static final String REDIS_KEY_ACCESS_TOKEN = "zfbAccessToken";

    @Autowired
    private AliPayService aliPayService;

    @Autowired
    private RedisUtils redisUtils;

    @Override
    public String getThirdPartyAuthoriseUrl(ProductInfo productInfo) {
        String arg = assembleQueryStringFromProductInfo(productInfo);
        String uri = AlipayConfig.AUTH_REDIRECT_URI.replace("MID", arg);
        try {
            // 回调地址必须encode
            uri = URLEncoder.encode(uri, CharactersConstant.CHARSET_UTF8);
        } catch (UnsupportedEncodingException e) {
            LogUtils.logErrorWithException(log, "扫码登录重定向-回调uri编码", LogConstant.RES_EXCEPTION, "", 0,
                    Integer.parseInt(productInfo.getMid()), "支付宝扫码登录重定向回调uri编码【失败】", e);
        }
        // 支付宝授权链接
        String url = AlipayConfig.AUTH_URL
                .replace("appId", AlipayConfig.APP_ID)
                .replace("redirectUri", uri);
        return url;
    }

    @Override
    public LoginOrRegisterResult getAuth(String code, String arg) {
        Assert.hasText(code, "code参数不能为空");
        Assert.hasText(arg, "arg参数不能为空");

        String accessToken = redisUtils.getString(REDIS_KEY_ACCESS_TOKEN);
        // 缓存中不存在access token时才向支付宝平台申请
        if (StringUtils.isBlank(accessToken)) {
            AlipaySystemOauthTokenResponse alipaySystemOauthTokenResponse = aliPayService.getAccessToken(code);
            if (alipaySystemOauthTokenResponse == null || StringUtils.isBlank(alipaySystemOauthTokenResponse.getAccessToken())) {
                return new LoginOrRegisterResult(ResultCode.ALIPAY_GET_ACCESS_TOKEN_FAIL.getCode());
            }

            accessToken = alipaySystemOauthTokenResponse.getAccessToken();
            // 把accessToken保存进redis，有效期按支付宝接口返回的ExpiresIn参数设置
            redisUtils.setStringAndExpire(REDIS_KEY_ACCESS_TOKEN, Integer.parseInt(alipaySystemOauthTokenResponse.getExpiresIn()),
                    alipaySystemOauthTokenResponse.getAccessToken());
        }

        AlipayUserInfoShareResponse alipayUserInfo = aliPayService.getUserInfo(accessToken);
        if (alipayUserInfo == null) {
            return new LoginOrRegisterResult(ResultCode.ALIPAY_GET_USERINFO_FAIL.getCode());
        }

        // 构建用户中心请求json的product节点
        ProductInfo productInfo = setProductInfo(arg);
        // 这里一定要传个空json对象
        productInfo.setInfo(new EmptyInfo());
        // 根据支付宝接口返回的用户信息vo封装为用户中心请求json的usrinfo节点
        UserRegisterReq.AlipayUserInfo userInfo = setUserInfo(alipayUserInfo);

        // 构建用户中心请求vo
        UserRegisterReq userRegisterReq = new UserRegisterReq();
        userRegisterReq.setProduct(productInfo);
        userRegisterReq.setUsrinfo(userInfo);
        userRegisterReq.setLoginId(alipayUserInfo.getUserId());
        userRegisterReq.setType(UserCenterConstant.TYPE_ALIPAY);
        userRegisterReq.setPwd(UserCenterConstant.PWD_NONE);

        Integer mid = Integer.parseInt(productInfo.getMid());
        // 调用用户中心注册登录接口
        LoginOrRegisterResult loginAndRegisterResult = loginOrRegisterFromUserCenter(userRegisterReq, mid);

        loginAndRegisterResult.setCouponId(productInfo.getCoupon_id());
        loginAndRegisterResult.setMid(mid);
        loginAndRegisterResult.setUnionId(alipayUserInfo.getUserId());
        return loginAndRegisterResult;
    }

    /**
     * 根据支付宝查询用户接口返回的用户信息vo封装为用户中心请求json的usrinfo节点
     *
     * @param alipayUserInfo 支付宝查询用户接口返回的vo
     * @return
     */
    private UserRegisterReq.AlipayUserInfo setUserInfo(AlipayUserInfoShareResponse alipayUserInfo) {
        UserRegisterReq.AlipayUserInfo userInfo = new UserRegisterReq.AlipayUserInfo();
        userInfo.setBindZfb(alipayUserInfo.getUserId());
        userInfo.setCity(alipayUserInfo.getCity());
        userInfo.setEx(UserCenterConstant.EX_ALIPAY);
        userInfo.setImageUrl(alipayUserInfo.getAvatar());
        userInfo.setName(alipayUserInfo.getNickName());
        userInfo.setProvince(alipayUserInfo.getProvince());

        // 0 未知性别 1 男性 2女性
        if (AlipayConstant.SEX_MALE.equalsIgnoreCase(alipayUserInfo.getGender())) {
            userInfo.setSex(UserCenterConstant.SEX_MALE);
        } else if (AlipayConstant.SEX_FEMALE.equalsIgnoreCase(alipayUserInfo.getGender())) {
            userInfo.setSex(UserCenterConstant.SEX_FEMALE);
        } else {
            userInfo.setSex(UserCenterConstant.SEX_UNKNOWN);
        }

        return userInfo;
    }
}
