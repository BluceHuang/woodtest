package com.meda.opa.pay.vo.user;

/**
 * 用户中心查询用户id服务请求vo
 *
 * @author Huangxiaodi
 * @date 2018/11/1
 */
public class RequestInGetUid {

    private String uid;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public RequestInGetUid() {

    }

    public RequestInGetUid(String uid) {
        this.uid = uid;
    }

    @Override
    public String toString() {
        return "RequestInGetUid{" +
                "uid='" + uid + '\'' +
                '}';
    }
}
