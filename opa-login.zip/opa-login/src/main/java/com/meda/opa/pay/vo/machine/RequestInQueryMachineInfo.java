package com.meda.opa.pay.vo.machine;


/**
 * 机器信息查询接口请求实体
 *
 * @author Huangxiaodi
 * @date 2018/10/24
 */
public class RequestInQueryMachineInfo {

    private String mid;

    public RequestInQueryMachineInfo() {

    }

    public RequestInQueryMachineInfo(String mid) {
        this.mid = mid;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    @Override
    public String toString() {
        return "RequestInQueryMachineInfo{" +
                "mid='" + mid + '\'' +
                '}';
    }
}
