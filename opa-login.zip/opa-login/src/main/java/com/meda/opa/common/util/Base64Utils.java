package com.meda.opa.common.util;


import com.meda.opa.common.constant.CharactersConstant;
import org.apache.commons.codec.binary.Base64;

/**
 * base64 加解密工具类
 *
 * @author Huangxiaodi
 * @date 2018/10/22
 */
public class Base64Utils {
    public static String decode(String s) {
        byte[] b = null;
        String result = null;
        if (s != null) {
            try {
                b = Base64.decodeBase64(s);
                result = new String(b, CharactersConstant.CHARSET_UTF8);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    public static String encode(String content) {
        try {
            byte[] bt = content.getBytes(CharactersConstant.CHARSET_UTF8);
            String result = Base64.encodeBase64String(bt);
            result = result.replaceAll("\\r|\\n", "");
            return result;
        } catch (Exception e) {
            return null;
        }
    }
}
