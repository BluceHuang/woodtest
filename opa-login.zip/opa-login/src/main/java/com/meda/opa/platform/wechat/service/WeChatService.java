package com.meda.opa.platform.wechat.service;

import com.meda.opa.platform.wechat.vo.OAuthToken;
import com.meda.opa.platform.wechat.vo.ResponseInGetUserinfo;

/**
 * 微信服务接口
 *
 * @author Huangxiaodi
 * @date 2018/10/18
 */
public interface WeChatService {

    /**
     * 使用票据code调用微信获取网页授权access_token接口
     *
     * @param appId
     * @param appSecret
     * @param code
     * @return
     */
    OAuthToken getAccessToken(String appId, String appSecret, String code);

    /**
     * 微信拉取用户信息
     *
     * @param accessToken
     * @param openId
     * @return
     */
    ResponseInGetUserinfo getUserinfo(String accessToken, String openId);
}
