package com.meda.opa.common.enums;

/**
 * 冲销类型枚举类
 *
 * @author Huangxiaodi
 * @date 2018/10/25
 */
public enum OrderChargeType {

    /**
     * 0: 不冲销
     */
    NOCHARGE(0, "不冲销"),

    /**
     * 1: 冲销
     */
    CHARGE(1, "冲销");


    private int code;

    private String description;

    OrderChargeType(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
