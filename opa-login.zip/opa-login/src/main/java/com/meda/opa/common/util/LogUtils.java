package com.meda.opa.common.util;

import com.meda.opa.common.constant.CharactersConstant;
import org.slf4j.Logger;

import java.io.*;

/**
 * logback 封装工具类
 *
 * @author Huangxiaodi
 * @date 2018/11/13
 */
public class LogUtils {

    /**
     * log debug级别日志
     *
     * @param log      log对象
     * @param business 业务名称
     * @param result   处理结果，如果是普通log，请传入LogConstant.NONE
     * @param uid      用户id
     * @param uno      整形用户id
     * @param mid      机器id
     * @param msg      自定义消息
     */
    public static void logDebug(Logger log, String business, String result, String uid, int uno, int mid, String msg) {
        StringBuffer logContent = buildCommonLogContent(business, result, uid, uno, mid, msg);
        log.debug(logContent.toString());
    }

    /**
     * log info级别日志
     *
     * @param log      log对象
     * @param business 业务名称
     * @param result   处理结果，如果是普通log，请传入LogConstant.NONE
     * @param uid      用户id
     * @param uno      整形用户id
     * @param mid      机器id
     * @param msg      自定义消息
     */
    public static void logInfo(Logger log, String business, String result, String uid, int uno, int mid, String msg) {
        StringBuffer logContent = buildCommonLogContent(business, result, uid, uno, mid, msg);
        log.info(logContent.toString());
    }

    /**
     * log warn级别日志
     *
     * @param log      log对象
     * @param business 业务名称
     * @param result   处理结果，如果是普通log，请传入LogConstant.NONE
     * @param uid      用户id
     * @param uno      整形用户id
     * @param mid      机器id
     * @param msg      自定义消息
     */
    public static void logWarn(Logger log, String business, String result, String uid, int uno, int mid, String msg) {
        StringBuffer logContent = buildCommonLogContent(business, result, uid, uno, mid, msg);
        log.warn(logContent.toString());
    }

    /**
     * log error级别日志
     *
     * @param log      log对象
     * @param business 业务名称
     * @param result   处理结果，如果是普通log，请传入LogConstant.NONE
     * @param uid      用户id
     * @param uno      整形用户id
     * @param mid      机器id
     * @param msg      自定义消息
     */
    public static void logError(Logger log, String business, String result, String uid, int uno, int mid, String msg) {
        StringBuffer logContent = buildCommonLogContent(business, result, uid, uno, mid, msg);
        log.error(logContent.toString());
    }

    /**
     * log error级别日志，并且log出异常堆栈信息
     *
     * @param log       log对象
     * @param business  业务名称
     * @param result    处理结果，如果是普通log，请传入LogConstant.NONE
     * @param uid       用户id
     * @param uno       整形用户id
     * @param mid       机器id
     * @param msg       自定义消息
     * @param throwable 异常对象
     */
    public static void logErrorWithException(Logger log, String business, String result, String uid, int uno, int mid, String msg, Throwable throwable) {
        StringBuffer logContent = buildCommonLogContent(business, result, uid, uno, mid, msg);
        logContent.append(",\"exception\":\"");
        logContent.append(assembleExceptionStack(throwable));
        logContent.append("\"");

        log.error(logContent.toString());
    }

    /**
     * 拼接通用log日志内容
     *
     * @param business 业务名称
     * @param result   处理结果
     * @param uid      用户id
     * @param uno      整形用户id
     * @param mid      机器id
     * @param msg      自定义消息
     * @return
     */
    private static StringBuffer buildCommonLogContent(String business, String result, String uid, int uno, int mid, String msg) {
        StringBuffer logContent = new StringBuffer("\"custom\":");
        logContent.append(true);
        logContent.append(",\"biz\":\"");
        logContent.append(business);
        logContent.append("\",\"res\":\"");
        logContent.append(result);
        logContent.append("\",\"uid\":\"");
        logContent.append(uid);
        logContent.append("\",\"uno\":");
        logContent.append(uno);
        logContent.append(",\"mid\":");
        logContent.append(mid);
        logContent.append(",\"msg\":\"");
        logContent.append(msg);
        logContent.append("\"");
        return logContent;
    }

    /**
     * 拼接异常堆栈信息
     *
     * @param throwable
     * @return
     */
    private static String assembleExceptionStack(Throwable throwable) {
        StringBuffer exceptionStack = new StringBuffer("");

        Exception t1 = (Exception) throwable;
        exceptionStack.append(t1.getMessage());
        exceptionStack.append("\n");

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        throwable.printStackTrace(pw);
        pw.flush();
        LineNumberReader reader = new LineNumberReader(new StringReader(
                sw.toString()));
        try {
            String line = reader.readLine();
            while (line != null) {
                exceptionStack.append(line);
                exceptionStack.append(CharactersConstant.ENTER_MARKER);
                line = reader.readLine();
            }
        } catch (IOException ex) {
            exceptionStack.append(ex.toString());
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException ioException) {
                ioException.printStackTrace();

                if (pw != null) {
                    pw.close();
                }
            }
        }
        return exceptionStack.toString();
    }
}
