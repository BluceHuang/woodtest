package com.meda.opa.login.service.auth.impl;

import com.meda.opa.common.constant.CharactersConstant;
import com.meda.opa.common.constant.HttpConstant;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.common.enums.ResultCode;
import com.meda.opa.common.enums.UserCenterRespCode;
import com.meda.opa.common.util.HttpUtil;
import com.meda.opa.common.util.LogUtils;
import com.meda.opa.config.SystemConfig;
import com.meda.opa.login.dto.LoginOrRegisterResult;
import com.meda.opa.login.vo.ProductInfo;
import com.meda.opa.login.service.auth.AuthService;
import com.meda.opa.login.vo.UserRegisterReq;
import com.meda.opa.login.vo.UserRegisterResp;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 授权登录服务抽象类
 *
 * @author Huangxiaodi
 * @date 2018/11/21.
 */
public abstract class AbstractAuthServiceImpl implements AuthService {

    private static Logger log = LoggerFactory.getLogger(AbstractAuthServiceImpl.class);

    private static final int NO_COUPONID_LENGTH = 4;

    private static final int COUPONID_LENGTH = 5;

    /**
     * 构建第三方网页授权url
     *
     * @param productInfo 产品服务器的相关参数
     * @return
     */
    @Override
    public abstract String getThirdPartyAuthoriseUrl(ProductInfo productInfo);

    /**
     * 用户中心授权
     *
     * @param code 第三方网页授权回调本系统uri时带回的code
     * @param arg  扫描二维码传回的参数包括了mid（机器ID）、type（产品的类型编号）、srv_uri（产品服务URI）等，用,分隔
     * @return
     */
    @Override
    public abstract LoginOrRegisterResult getAuth(String code, String arg);

    /**
     * 用户中心注册或登录操作
     *
     * @param userRegisterReq 用户中心注册登录请求vo
     * @param mid             机器id
     * @return 响应码
     */
    protected LoginOrRegisterResult loginOrRegisterFromUserCenter(UserRegisterReq userRegisterReq, int mid) {
        try {
            LogUtils.logDebug(log, "用户中心注册登录", LogConstant.RES_NONE, "", 0, mid, "访问用户中心注册登录接口，请求内容为：" + userRegisterReq);

            UserRegisterResp userRegisterResp = HttpUtil.sendJsonDataAndGetResponseEntity(false,
                    SystemConfig.REGISTER_AND_LOGIN_URL, HttpConstant.REQUEST_METHOD_PUT, userRegisterReq, UserRegisterResp.class);

            if (UserCenterRespCode.SUCCESS.getResCode() != userRegisterResp.getStatus()) {
                LogUtils.logError(log, "用户中心注册登录", LogConstant.RES_FAIL, "", 0, mid, "访问用户中心注册登录接口返回【错误】：" + userRegisterResp);
                return new LoginOrRegisterResult(ResultCode.REGISTER_LOGIN_FAIL.getCode());
            }

            UserRegisterResp.ProductBody product = userRegisterResp.getProduct();
            if (product == null || UserCenterRespCode.SUCCESS.getResCode() != product.getStatus()) {
                LogUtils.logError(log, "用户中心注册登录-产品服务", LogConstant.RES_FAIL, "", userRegisterResp.getData().getUno(), mid, "访问产品服务返回【错误】：" + userRegisterResp);
                return new LoginOrRegisterResult(ResultCode.PRODUCT_SERVER_EXCEPTION.getCode());
            }

            LogUtils.logInfo(log, "用户中心注册登录", LogConstant.RES_SUCCESS, "", userRegisterResp.getData().getUno(), mid, "访问用户中心注册登录接口【成功】");
            return new LoginOrRegisterResult(ResultCode.SUCCESS.getCode(), userRegisterResp.getData().getUid(), userRegisterResp.getData().getUno());
        } catch (Exception e) {
            LogUtils.logErrorWithException(log, "用户中心注册登录", LogConstant.RES_EXCEPTION, "", 0, mid, "访问用户中心注册登录接口【异常】", e);
            return new LoginOrRegisterResult(ResultCode.USER_CENTER_RESPONSE_FAIL.getCode());
        }
    }

    /**
     * 根据扫码带回的产品参数拼接query string
     *
     * @param productInfo 产品信息vo
     * @return
     */
    protected String assembleQueryStringFromProductInfo(ProductInfo productInfo) {
        // 扫描二维码传回的产品参数包括了mid（机器ID）、ptype（产品的类型编号）、srv_uri（回调URI），用,分隔传给getAuth方法
        StringBuilder queryString = new StringBuilder();
        queryString
                .append(productInfo.getMid())
                .append(CharactersConstant.COMMA)
                .append(productInfo.getPtype())
                .append(CharactersConstant.COMMA)
                .append(productInfo.getMethod())
                .append(CharactersConstant.COMMA)
                .append(productInfo.getSrv_uri())
                .append(CharactersConstant.COMMA)
                .append(productInfo.getPath());

        if (StringUtils.isNotBlank(productInfo.getCoupon_id())) {
            queryString.append(CharactersConstant.COMMA);
            queryString.append(productInfo.getCoupon_id());
        }

        return queryString.toString();
    }

    /**
     * 构建用户中心请求vo的product节点
     *
     * @param arg
     * @return
     */
    protected ProductInfo setProductInfo(String arg) {
        ProductInfo productInfo = new ProductInfo();
        String[] arr = arg.split(",");
        if (arr.length > NO_COUPONID_LENGTH) {
            productInfo.setMid(arr[0]);
            productInfo.setPtype(arr[1]);
            productInfo.setMethod(arr[2]);
            productInfo.setSrv_uri(arr[3]);
            productInfo.setPath(arr[4]);
            if (arr.length > COUPONID_LENGTH) {
                productInfo.setCoupon_id(arr[5]);
            }
        }

        return productInfo;
    }
}
