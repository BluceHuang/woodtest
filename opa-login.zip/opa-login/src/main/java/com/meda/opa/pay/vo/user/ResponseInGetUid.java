package com.meda.opa.pay.vo.user;

/**
 * 用户中心查询用户id服务响应vo
 *
 * @author Huangxiaodi
 * @date 2018/11/1
 */
public class ResponseInGetUid {

    private int status;

    private DataBody data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public DataBody getData() {
        return data;
    }

    public void setData(DataBody data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ResponseInGetUid{" +
                "status=" + status +
                ", data=" + data +
                '}';
    }

    public static class DataBody {

        private String uid;

        private int uno;

        public String getUid() {
            return uid;
        }

        public void setUid(String uid) {
            this.uid = uid;
        }

        public int getUno() {
            return uno;
        }

        public void setUno(int uno) {
            this.uno = uno;
        }

        @Override
        public String toString() {
            return "DataBody{" +
                    "uid='" + uid + '\'' +
                    ", uno=" + uno +
                    '}';
        }
    }
}
