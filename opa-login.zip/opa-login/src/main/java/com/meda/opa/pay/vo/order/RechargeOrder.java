package com.meda.opa.pay.vo.order;

import com.alibaba.fastjson.annotation.JSONField;
import com.meda.opa.common.enums.*;

/**
 * 支付网关获取PrePayId接口请求实体
 *
 * @author Huangxiaodi
 * @date 2018/10/24
 */
public class RechargeOrder {

    @JSONField(name = "from_appid")
    private String fromAppId;

    @JSONField(name = "from_appname")
    private String fromAppName;

    @JSONField(name = "openid")
    private String openId = "";

    private int uid = 0;

    private int mid = 0;

    @JSONField(name = "gold_count")
    private int goldCount = 0;

    private String ip = "";

    @JSONField(name = "buy_type")
    private int buyType = OrderBuyType.GOLD.getCode();

    @JSONField(name = "packet_id")
    private int packetId = 0;

    @JSONField(name = "total_fee")
    private int totalFee = 0;

    private String title;

    private String detail;

    @JSONField(name = "day_type")
    private int dayType = OrderDayType.WORKDAY.getCode();

    @JSONField(name = "time_type")
    private int timeType = OrderTimeType.NORMAL.getCode();

    private int charge = OrderChargeType.NOCHARGE.getCode();

    private int version = 0;

    private int timestamp = (int) (System.currentTimeMillis() / 1000);

    @JSONField(name = "product_type")
    private int productType = OrderProductType.UNIONMINIK.getCode();

    @JSONField(name = "uniq_sn")
    private String uniqSn = "";

    @JSONField(name = "no_need_pay")
    private int noNeedPay = 0;

    @JSONField(name = "refund_order_id")
    private String refundOrderId;

    @JSONField(name = "refund_trade_no")
    private String refundTradeNo;

    @JSONField(name = "srvindex")
    private int srvIndex;

    @JSONField(name = "cost_mode")
    private int costMode;

    @JSONField(name = "time_seconds")
    private int timeSeconds;

    public RechargeOrder() {

    }

    public RechargeOrder(String openId, int uid, int mid, String ip, int packetId, String title, String detail, int buyType, int productType, int costMode, int timeSeconds) {
        this.openId = openId;
        this.uid = uid;
        this.mid = mid;
        this.ip = ip;
        this.packetId = packetId;
        this.title = title;
        this.detail = detail;
        this.buyType = buyType;
        this.productType = productType;
        this.costMode = costMode;
        this.timeSeconds = timeSeconds;
    }

    public RechargeOrder(String fromAppId, String fromAppName, String openId, int uid, int mid, String ip, int packetId, String title, String detail, int buyType, int productType, int srvIndex, int costMode, int timeSeconds) {
        this.fromAppId = fromAppId;
        this.fromAppName = fromAppName;
        this.openId = openId;
        this.uid = uid;
        this.mid = mid;
        this.ip = ip;
        this.packetId = packetId;
        this.title = title;
        this.detail = detail;
        this.buyType = buyType;
        this.productType = productType;
        this.srvIndex = srvIndex;
        this.costMode = costMode;
        this.timeSeconds = timeSeconds;
    }

    public String getFromAppId() {
        return fromAppId;
    }

    public void setFromAppId(String fromAppId) {
        this.fromAppId = fromAppId;
    }

    public String getFromAppName() {
        return fromAppName;
    }

    public void setFromAppName(String fromAppName) {
        this.fromAppName = fromAppName;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getMid() {
        return mid;
    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    public int getGoldCount() {
        return goldCount;
    }

    public void setGoldCount(int goldCount) {
        this.goldCount = goldCount;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getBuyType() {
        return buyType;
    }

    public void setBuyType(int buyType) {
        this.buyType = buyType;
    }

    public int getPacketId() {
        return packetId;
    }

    public void setPacketId(int packetId) {
        this.packetId = packetId;
    }

    public int getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(int totalFee) {
        this.totalFee = totalFee;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public int getDayType() {
        return dayType;
    }

    public void setDayType(int dayType) {
        this.dayType = dayType;
    }

    public int getTimeType() {
        return timeType;
    }

    public void setTimeType(int timeType) {
        this.timeType = timeType;
    }

    public int getCharge() {
        return charge;
    }

    public void setCharge(int charge) {
        this.charge = charge;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public int getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(int timestamp) {
        this.timestamp = timestamp;
    }

    public int getProductType() {
        return productType;
    }

    public void setProductType(int productType) {
        this.productType = productType;
    }

    public String getUniqSn() {
        return uniqSn;
    }

    public void setUniqSn(String uniqSn) {
        this.uniqSn = uniqSn;
    }

    public int getNoNeedPay() {
        return noNeedPay;
    }

    public void setNoNeedPay(int noNeedPay) {
        this.noNeedPay = noNeedPay;
    }

    public String getRefundOrderId() {
        return refundOrderId;
    }

    public void setRefundOrderId(String refundOrderId) {
        this.refundOrderId = refundOrderId;
    }

    public String getRefundTradeNo() {
        return refundTradeNo;
    }

    public void setRefundTradeNo(String refundTradeNo) {
        this.refundTradeNo = refundTradeNo;
    }

    public int getSrvIndex() {
        return srvIndex;
    }

    public void setSrvIndex(int srvIndex) {
        this.srvIndex = srvIndex;
    }

    public int getCostMode() {
        return costMode;
    }

    public void setCostMode(int costMode) {
        this.costMode = costMode;
    }

    public int getTimeSeconds() {
        return timeSeconds;
    }

    public void setTimeSeconds(int timeSeconds) {
        this.timeSeconds = timeSeconds;
    }

    @Override
    public String toString() {
        return "RechargeOrder{" +
                "fromAppId='" + fromAppId + '\'' +
                ", fromAppName='" + fromAppName + '\'' +
                ", openId='" + openId + '\'' +
                ", uid=" + uid +
                ", mid=" + mid +
                ", goldCount=" + goldCount +
                ", ip='" + ip + '\'' +
                ", buyType=" + buyType +
                ", packetId=" + packetId +
                ", totalFee=" + totalFee +
                ", title='" + title + '\'' +
                ", detail='" + detail + '\'' +
                ", dayType=" + dayType +
                ", timeType=" + timeType +
                ", charge=" + charge +
                ", version=" + version +
                ", timestamp=" + timestamp +
                ", productType=" + productType +
                ", uniqSn='" + uniqSn + '\'' +
                ", noNeedPay=" + noNeedPay +
                ", refundOrderId='" + refundOrderId + '\'' +
                ", refundTradeNo='" + refundTradeNo + '\'' +
                ", srvIndex=" + srvIndex +
                ", costMode=" + costMode +
                ", timeSeconds=" + timeSeconds +
                '}';
    }
}
