package com.meda.opa.pay.vo.user;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * 查询该用户是否具备付费资格接口的请求实体
 *
 * @author Huangxiaodi
 * @date 2018/10/24
 */
public class RequestInCheckPayStatus {

    private int uno;

    private String uid;

    @JSONField(name = "goods_id")
    private int goodsId;

    @JSONField(name = "cost_mode")
    private int costMode;

    @JSONField(name = "time_seconds")
    private int timeSeconds;

    @JSONField(name = "srvindex")
    private int srvIndex;

    @JSONField(name = "usecoupon")
    private int useCoupon;

    public RequestInCheckPayStatus() {

    }

    public RequestInCheckPayStatus(int uno, String uid, int goodsId, int costMode, int timeSeconds, int srvIndex, int useCoupon) {
        this.uno = uno;
        this.uid = uid;
        this.goodsId = goodsId;
        this.costMode = costMode;
        this.timeSeconds = timeSeconds;
        this.srvIndex = srvIndex;
        this.useCoupon = useCoupon;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public int getUno() {
        return uno;
    }

    public void setUno(int uno) {
        this.uno = uno;
    }

    public int getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(int goodsId) {
        this.goodsId = goodsId;
    }

    public int getCostMode() {
        return costMode;
    }

    public void setCostMode(int costMode) {
        this.costMode = costMode;
    }

    public int getTimeSeconds() {
        return timeSeconds;
    }

    public void setTimeSeconds(int timeSeconds) {
        this.timeSeconds = timeSeconds;
    }

    public int getSrvIndex() {
        return srvIndex;
    }

    public void setSrvIndex(int srvIndex) {
        this.srvIndex = srvIndex;
    }

    public int getUseCoupon() {
        return useCoupon;
    }

    public void setUseCoupon(int useCoupon) {
        this.useCoupon = useCoupon;
    }

    @Override
    public String toString() {
        return "RequestInCheckPayStatus{" +
                "uno=" + uno +
                ", uid='" + uid + '\'' +
                ", goodsId=" + goodsId +
                ", costMode=" + costMode +
                ", timeSeconds=" + timeSeconds +
                ", srvIndex=" + srvIndex +
                ", useCoupon=" + useCoupon +
                '}';
    }
}
