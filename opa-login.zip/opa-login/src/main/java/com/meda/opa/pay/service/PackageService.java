package com.meda.opa.pay.service;

import com.meda.opa.pay.vo.user.ResponseInCheckPayStatus;

/**
 * 套餐服务接口
 *
 * @author Huangxiaodi
 * @date 2018/11/7
 */
public interface PackageService {

    /**
     * 构建购买套餐重定向url
     *
     * @param uid      字符串用户id
     * @param uno      整数型用户id
     * @param mid      机器id
     * @param unionId  微信unionId
     * @param couponId 优惠券id
     * @return
     */
    String buildPackageBuyRedirectUrl(String uid, String uno, String mid, String unionId, String couponId);

    /**
     * 查询该用户是否具备付费资格或通知使用优惠券，并返回支付总金额
     *
     * @param uno         用户整形id
     * @param uid         用户id
     * @param mid         机器id
     * @param packageId   套餐id
     * @param costMode    消费模式
     * @param timeSeconds 时长
     * @param source      服务器组id
     * @param useCoupon   使用优惠券标识
     * @return
     */
    ResponseInCheckPayStatus checkPayStatus(int uno, String uid, int mid, int packageId, int costMode, int timeSeconds, int source, int useCoupon);
}
