package com.meda.opa.common.util;

import org.apache.commons.codec.digest.DigestUtils;

/**
 * Md5工具类
 *
 * @author Huangxiaodi
 * @date 2018/11/6
 */
public class MD5Utils {

    /**
     * MD5方法
     *
     * @param text 明文
     * @return 密文
     * @throws Exception
     */
    public static String md5(String text) throws Exception {
        String encodeStr = DigestUtils.md5Hex(text);
        return encodeStr;
    }
}
