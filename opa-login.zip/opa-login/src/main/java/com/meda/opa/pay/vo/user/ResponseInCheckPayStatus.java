package com.meda.opa.pay.vo.user;

/**
 * 查询该用户是否具备付费资格接口的响应实体
 *
 * @author Huangxiaodi
 * @date 2018/10/23
 */
public class ResponseInCheckPayStatus {

    private int status;

    private int pay;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPay() {
        return pay;
    }

    public void setPay(int pay) {
        this.pay = pay;
    }

    @Override
    public String toString() {
        return "ResponseInCheckPayStatus{" +
                "status=" + status +
                ", pay=" + pay +
                '}';
    }
}
