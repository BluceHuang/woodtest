package com.meda.opa.login.vo;

import com.alibaba.fastjson.annotation.JSONField;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 产品信息vo
 *
 * @author yuanzipeng
 * @date 2018/9/13.
 */
public class ProductInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 机器ID
     */
    @NotNull(message = "机器ID不能为空")
    private String mid;

    /**
     * 产品的类型编号
     */
    @NotNull(message = "产品类型不能为空")
    private String ptype;

    /**
     * 请求服务的方式
     */
    @NotNull(message = "请求服务的方式不能为空")
    private String method;

    /**
     * 产品服务器地址以及端口号
     */
    @NotNull(message = "产品服务器地址以及端口号不能为空")
    private String srv_uri;

    /**
     * 产品服务的http路径
     */
    @NotNull(message = "产品服务的请求路径不能为空")
    private String path;
    /**
     * 优惠券套餐id
     */
    @JSONField(serialize = false)
    private String coupon_id;

    private EmptyInfo info;

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getPtype() {
        return ptype;
    }

    public void setPtype(String ptype) {
        this.ptype = ptype;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getSrv_uri() {
        return srv_uri;
    }

    public void setSrv_uri(String srv_uri) {
        this.srv_uri = srv_uri;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getCoupon_id() {
        return coupon_id;
    }

    public void setCoupon_id(String coupon_id) {
        this.coupon_id = coupon_id;
    }

    public EmptyInfo getInfo() {
        return info;
    }

    public void setInfo(EmptyInfo info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "ProductInfo{" +
                "mid='" + mid + '\'' +
                ", ptype='" + ptype + '\'' +
                ", method='" + method + '\'' +
                ", srv_uri='" + srv_uri + '\'' +
                ", path='" + path + '\'' +
                ", coupon_id='" + coupon_id + '\'' +
                ", info=" + info +
                '}';
    }
}
