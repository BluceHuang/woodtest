package com.meda.opa.pay.vo.coupon;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * 优惠券服务响应实体
 *
 * @author Huangxiaodi
 * @date 2018/10/23
 */
public class ResponseInCoupon {

    @JSONField(name = "seqno")
    private String seqNo;

    private String cmd;

    private Integer status;

    private DataBody data;

    private String msg;

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo == null ? "" : seqNo;
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public DataBody getData() {
        return data;
    }

    public void setData(DataBody data) {
        this.data = data;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "ResponseInCoupon{" +
                "seqNo='" + seqNo + '\'' +
                ", cmd='" + cmd + '\'' +
                ", status=" + status +
                ", data=" + data +
                ", msg='" + msg + '\'' +
                '}';
    }

    public static class DataBody {

        @JSONField(name = "coupons_id")
        private String couponsId;

        @JSONField(name = "coupons_status")
        private int couponsStatus;

        @JSONField(name = "free_type")
        private int freeType;

        @JSONField(name = "free_duration")
        private int freeDuration;

        public String getCouponsId() {
            return couponsId;
        }

        public void setCouponsId(String couponsId) {
            this.couponsId = couponsId == null || couponsId.equals("null") ? "" : couponsId;
        }

        public int getCouponsStatus() {
            return couponsStatus;
        }

        public void setCouponsStatus(int couponsStatus) {
            this.couponsStatus = couponsStatus;
        }

        public int getFreeType() {
            return freeType;
        }

        public void setFreeType(int freeType) {
            this.freeType = freeType;
        }

        public int getFreeDuration() {
            return freeDuration;
        }

        public void setFreeDuration(int freeDuration) {
            this.freeDuration = freeDuration;
        }

        @Override
        public String toString() {
            return "DataBody{" +
                    "couponsId='" + couponsId + '\'' +
                    ", couponsStatus=" + couponsStatus +
                    ", freeType=" + freeType +
                    ", freeDuration=" + freeDuration +
                    '}';
        }
    }
}
