package com.meda.opa.common.enums;

/**
 * 优惠券状态枚举类
 *
 * @author Huangxiaodi
 * @date 2018/10/23
 */
public enum CouponStatus {
    /**
     * 0: 券已经被使用
     */
    USEED(0, "券已经被使用"),

    /**
     * 1: 券可以正常使用
     */
    AVAILABLE(1, "券可以正常使用"),

    /**
     * -1: 活动已经结束
     */
    ACTION_ENDED(-1, "活动已经结束"),

    /**
     * -2: 活动尚未开始
     */
    ACTION_NOT_START(-2, "活动尚未开始"),

    /**
     * -3: 无此数据
     */
    NO_DATA(-3, "无此数据"),

    /**
     * -4: 错误
     */
    ERROR(-4, "错误"),

    /**
     * -5：通知使用优惠券失败
     */
    NOFITY_FAIL(-5, "通知使用优惠券失败");

    private int code;

    private String description;

    CouponStatus(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
