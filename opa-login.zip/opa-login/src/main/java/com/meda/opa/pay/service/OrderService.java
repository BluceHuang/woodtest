package com.meda.opa.pay.service;


import com.meda.opa.pay.vo.order.PrePayIdResponse;
import com.meda.opa.pay.vo.order.RechargeOrder;

import java.util.Map;

/**
 * 订单服务接口
 *
 * @author Huangxiaodi
 * @date 2018/10/24
 */
public interface OrderService {

    /**
     * 构建微信支付订单
     *
     * @param order   订单vo
     * @param appType app类型 0:普通 1:小程序
     * @return
     */
    Map<String, String> generateOrder(RechargeOrder order, int appType);

    /**
     * 获取预支付id
     *
     * @param order   订单vo
     * @param mid     机器id
     * @param appType app类型 0:普通 1:小程序
     * @return
     */
    PrePayIdResponse unifiedOrder(RechargeOrder order, int mid, int appType);
}
