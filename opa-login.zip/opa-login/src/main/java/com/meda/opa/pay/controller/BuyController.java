package com.meda.opa.pay.controller;

import com.meda.opa.common.constant.CouponConstant;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.common.enums.OrderBuyType;
import com.meda.opa.common.enums.OrderProductType;
import com.meda.opa.common.enums.ResultCode;
import com.meda.opa.config.EnvConfig;
import com.meda.opa.config.MinishowConfig;
import com.meda.opa.config.WeChatConfig;
import com.meda.opa.pay.service.OrderService;
import com.meda.opa.pay.service.PackageService;
import com.meda.opa.pay.service.UserService;
import com.meda.opa.pay.vo.user.ResponseInCheckPayStatus;
import com.meda.opa.platform.wechat.service.WeChatService;
import com.meda.opa.pay.vo.*;
import com.meda.opa.pay.vo.order.RechargeOrder;
import com.meda.opa.platform.wechat.vo.OAuthToken;
import com.meda.opa.common.util.Base64Utils;
import com.meda.opa.common.util.IpUtils;
import com.meda.opa.common.util.LogUtils;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * 套餐购买控制器
 *
 * @author Huangxiaodi
 * @date 2018/10/24
 */
@RequestMapping("/minishow")
@RestController
public class BuyController {

    private static final Logger log = LoggerFactory.getLogger(BuyController.class);

    @Autowired
    private WeChatService weChatService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private UserService userService;

    @Autowired
    private PackageService packageService;

    /**
     * 点歌页面重定向
     *
     * @param code   微信授权返回code
     * @param state  微信授权返回state
     * @param target 待重定向的购买url
     * @return
     */
    @RequestMapping(value = "/buy_redirect")
    public RedirectView buyRedirectHandler(@RequestParam(name = "code", required = true) String code,
                                           @RequestParam(name = "state", required = true) String state,
                                           @RequestParam(name = "target", required = true) String target) {
        if (StringUtils.isBlank(code) || !"minishow_buy".equals(state) || StringUtils.isBlank(target)) {
            return new RedirectView(MinishowConfig.ORDER_SONG_REDIRECT_PARAM_ERROR_URL);
        }

        OAuthToken oAuthToken = weChatService.getAccessToken(WeChatConfig.PAY_APP_ID, WeChatConfig.PAY_APP_SECRET, code);
        if (oAuthToken == null || StringUtils.isBlank(oAuthToken.getOpenId())) {
            return new RedirectView(MinishowConfig.WECHAT_GET_PAY_ACCESS_TOKEN_ERROR_URL);
        }

        String targetUrl = Base64Utils.decode(target) + "&openId=" + oAuthToken.getOpenId();
        LogUtils.logInfo(log, "点歌页面重定向", LogConstant.RES_NONE, "", 0, 0, "点歌页面重定向成功，url为：" + targetUrl);
        return new RedirectView(targetUrl);
    }

    /**
     * 生成微信支付订单
     *
     * @param buyRequest 支付请求体
     * @param request
     * @return
     */
    @HystrixCommand(fallbackMethod = "generateOrderFail")
    @CrossOrigin(origins = "${minishow.access_control.allow_origin}", methods = RequestMethod.POST, allowCredentials = "true")
    @RequestMapping(value = "/buy", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public Object buyHandler(@RequestBody(required = true) @Validated BuyRequest buyRequest, HttpServletRequest request) {
        LogUtils.logDebug(log, "生成微信支付订单", LogConstant.RES_NONE, buyRequest.getUid(), buyRequest.getUno(),
                buyRequest.getMid(), "待生成微信支付订单，请求参数为：" + buyRequest);

        String uid = buyRequest.getUid();
        int uno = buyRequest.getUno();
        int mid = buyRequest.getMid();

        // 通过用户中心查询出uno
        UserIdentification userIdentification = userService.getUserIdentification(uid);
        // 用户中心查询出的uno要求与前端的一致
        if (userIdentification == null || userIdentification.getUno() != uno) {
            return new ResponseEntity<>(false, ResultCode.USER_NOT_EXIST.getCode(), ResultCode.USER_NOT_EXIST.getDescription());
        }

        String clientIp = IpUtils.getIp(request);
        // 校验用户是否具有付费资格，且告知用户需要支付金额
        ResponseInCheckPayStatus responseInCheckPayStatus = packageService.checkPayStatus(buyRequest.getUno(), buyRequest.getUid(), buyRequest.getMid(), buyRequest.getPacket_id(),
                buyRequest.getCost_mode(), buyRequest.getTime_seconds(), buyRequest.getSource(), CouponConstant.FLAG_NO_USE_COUPON);

        if (responseInCheckPayStatus != null) {
            int totalToPay = responseInCheckPayStatus.getPay();
            String title = Base64Utils.encode("mini秀套餐");
            RechargeOrder rechargeOrder = new RechargeOrder(WeChatConfig.APP_ID, MinishowConfig.APP_NAME,
                    buyRequest.getOpenid(), buyRequest.getUno(), buyRequest.getMid(),
                    clientIp, buyRequest.getPacket_id(), title, title,
                    OrderBuyType.PACKAGE.getCode(), OrderProductType.MINISHOW.getCode(), buyRequest.getSource(),
                    buyRequest.getCost_mode(), buyRequest.getTime_seconds());
            if (totalToPay == 0) {
                rechargeOrder.setNoNeedPay(1);
            }
            if (EnvConfig.ENV_TEST) {
                rechargeOrder.setTotalFee(1);
            } else {
                rechargeOrder.setTotalFee(totalToPay);
            }
            // 构建微信支付订单数据
            Map<String, String> responseMap = orderService.generateOrder(rechargeOrder, buyRequest.getApp_type());

            if (responseMap == null) {
                return new ResponseEntity<>(false, ResultCode.PRE_PAY_FAIL.getCode(), ResultCode.PRE_PAY_FAIL.getDescription());
            }

            LogUtils.logInfo(log, "生成微信支付订单", LogConstant.RES_SUCCESS, uid, uno, mid, "生成微信支付订单参数成功：" + responseMap);

            return new ResponseEntity<>(true, ResultCode.SUCCESS.getCode(), ResultCode.SUCCESS.getDescription(), responseMap);
        } else {
            return new ResponseEntity<>(false, ResultCode.GET_PAY_AMOUNT_FAIL.getCode(), ResultCode.GET_PAY_AMOUNT_FAIL.getDescription());
        }
    }

    /**
     * 对应buyHandler的服务降级方法
     *
     * @param requestInMinishowBuy
     * @param request
     * @return
     */
    public Object generateOrderFail(BuyRequest requestInMinishowBuy, HttpServletRequest request) {
        CommonResponseDataBody dataBody = new CommonResponseDataBody(-500);
        return new ResponseEntity<>(false, ResultCode.BUSY.getCode(), ResultCode.BUSY.getDescription(), dataBody);
    }

}
