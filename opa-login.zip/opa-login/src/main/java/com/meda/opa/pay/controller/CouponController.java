package com.meda.opa.pay.controller;

import com.meda.opa.common.constant.CouponConstant;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.common.enums.CouponStatus;
import com.meda.opa.common.util.LogUtils;
import com.meda.opa.pay.service.CouponService;
import com.meda.opa.pay.service.PackageService;
import com.meda.opa.pay.vo.CouponRequest;
import com.meda.opa.pay.vo.coupon.ResponseInCoupon;
import com.meda.opa.pay.vo.user.ResponseInCheckPayStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 优惠券控制器
 *
 * @author Huangxiaodi
 * @date 2018/11/12
 */
@RequestMapping("/minishow")
@RestController
public class CouponController {

    private static final Logger log = LoggerFactory.getLogger(CouponController.class);

    @Autowired
    private CouponService couponService;

    @Autowired
    private PackageService packageService;

    /**
     * 使用优惠券
     *
     * @param couponRequest 请求vo
     * @return
     */
    @CrossOrigin(origins = "${minishow.access_control.allow_origin}", methods = RequestMethod.POST, allowCredentials = "true")
    @RequestMapping(value = "/use_coupon", method = RequestMethod.POST)
    public Object useCouponHandler(@RequestBody(required = true) @Validated CouponRequest couponRequest) {
        int couponStatus;

        ResponseInCheckPayStatus responseInCheckPayStatus = packageService.checkPayStatus(couponRequest.getUno(),
                couponRequest.getUid(), couponRequest.getMid(), CouponConstant.GOODS_ID_IN_USE_COUPON, couponRequest.getCost_mode(),
                couponRequest.getTime_seconds(), couponRequest.getSource(), CouponConstant.FLAG_USE_COUPON);
        if (responseInCheckPayStatus == null) {
            couponStatus = CouponStatus.NOFITY_FAIL.getCode();
            LogUtils.logError(log, "使用优惠券", LogConstant.RES_FAIL, couponRequest.getUid(), couponRequest.getUno(),
                    couponRequest.getMid(), "通知使用优惠券失败");
        } else {
            ResponseInCoupon responseInCoupon = couponService.useCoupon(couponRequest);
            couponStatus = responseInCoupon.getData().getCouponsStatus();
            LogUtils.logInfo(log, "使用优惠券", LogConstant.RES_SUCCESS, couponRequest.getUid(), couponRequest.getUno(),
                    couponRequest.getMid(), "访问使用优惠券服务成功，返回优惠券状态为（1为正常使用）：" + couponStatus);
        }

        Map<String, Object> responseMap = new HashMap<>(8);
        responseMap.put("openid", couponRequest.getOpenid());
        responseMap.put("uid", couponRequest.getUid());
        responseMap.put("uno", couponRequest.getUno());
        responseMap.put("mid", couponRequest.getMid());
        responseMap.put("source", couponRequest.getSource());
        responseMap.put("cost_mode", couponRequest.getCost_mode());
        responseMap.put("time_seconds", couponRequest.getTime_seconds());
        responseMap.put("status", couponStatus);
        responseMap.put("coupon_id", couponRequest.getCoupon_id());

        return responseMap;
    }
}
