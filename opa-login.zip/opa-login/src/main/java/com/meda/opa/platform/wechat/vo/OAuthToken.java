package com.meda.opa.platform.wechat.vo;


import com.alibaba.fastjson.annotation.JSONField;

/**
 * 微信获取网页授权access_token接口响应实体
 *
 * @author Huangxiaodi
 * @date 2018/10/18
 */
public class OAuthToken {

    @JSONField(name = "openid")
    private String openId;

    @JSONField(name = "access_token")
    private String accessToken;

    @JSONField(name = "unionid")
    private String unionId;

    @JSONField(name = "errcode")
    private int errCode;

    @JSONField(name = "errmsg")
    private String errMsg;

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getUnionId() {
        return unionId;
    }

    public void setUnionId(String unionId) {
        this.unionId = unionId;
    }

    public int getErrCode() {
        return errCode;
    }

    public void setErrCode(int errCode) {
        this.errCode = errCode;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

    @Override
    public String toString() {
        return "OAuthToken{" +
                "openId='" + openId + '\'' +
                ", accessToken='" + accessToken + '\'' +
                ", unionId='" + unionId + '\'' +
                ", errCode=" + errCode +
                ", errMsg='" + errMsg + '\'' +
                '}';
    }
}
