package com.meda.opa.common.enums;

/**
 * 日期类型枚举类
 *
 * @author Huangxiaodi
 * @date 2018/10/25
 */
public enum OrderDayType {
    /**
     * 0: 工作日
     */
    WORKDAY(0, "工作日"),

    /**
     * 1: 节假日
     */
    HOLIDAY(1, "节假日");

    private int code;

    private String description;

    OrderDayType(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
