package com.meda.opa.pay.vo;

/**
 * 通用接口响应数据实体
 *
 * @author Huangxiaodi
 * @date 2018/10/25
 */
public class CommonResponseDataBody {

    private int status;

    public CommonResponseDataBody() {

    }

    public CommonResponseDataBody(int status) {
        this.status = status;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "CommonResponseDataBody{" +
                "status=" + status +
                '}';
    }
}
