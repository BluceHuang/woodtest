package com.meda.opa.common.util;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * 线程安全的日期工具类
 *
 * @author Huangxiaodi
 * @date 2018/10/23
 */
public class DateUtils {

    public static final DateTimeFormatter MILLIS_PIPELINE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");

    public static final DateTimeFormatter NO_MILLIS_PIPELINE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    /**
     * 将指定日期对象转换为指定格式的字符串
     *
     * @param date
     * @param formatter
     * @return
     */
    public static String getDateStr(Date date, DateTimeFormatter formatter) {
        LocalDateTime localDateTime;
        if (date == null) {
            localDateTime = LocalDateTime.now();
        } else {
            Instant instant = date.toInstant();
            ZoneId zoneId = ZoneId.systemDefault();
            localDateTime = instant.atZone(zoneId).toLocalDateTime();
        }
        return formatter.format(localDateTime);
    }
}
