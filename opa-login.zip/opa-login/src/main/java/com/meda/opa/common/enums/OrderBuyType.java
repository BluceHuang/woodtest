package com.meda.opa.common.enums;

/**
 * 订单购买类型枚举类
 *
 * @author Huangxiaodi
 * @date 2018/10/25
 */
public enum OrderBuyType {
    /**
     * 0: 购买金币
     */
    GOLD(0, "购买金币"),
    /**
     * 1: 购买套餐
     */
    PACKAGE(1, "购买套餐");

    private int code;

    private String description;

    OrderBuyType(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
