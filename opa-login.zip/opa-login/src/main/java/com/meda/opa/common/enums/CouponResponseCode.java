package com.meda.opa.common.enums;

/**
 * 优惠券接口响应枚举类
 *
 * @author Huangxiaodi
 * @date 2018/10/22
 */
public enum CouponResponseCode {
    /**
     * 0: 成功
     */
    SUCCESS(0, "成功");

    private int resCode;

    private String msg;

    CouponResponseCode(int resCode, String msg) {
        this.resCode = resCode;
        this.msg = msg;
    }

    public int getResCode() {
        return resCode;
    }

    public void setResCode(int resCode) {
        this.resCode = resCode;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
