package com.meda.opa.common.constant;

/**
 * 优惠券常量类
 *
 * @author Huangxiaodi
 * @date 2018/11/28
 */
public class CouponConstant {

    /**
     * 表示使用了优惠券
     */
    public static final int FLAG_USE_COUPON = 1;

    /**
     * 表示未使用优惠券
     */
    public static final int FLAG_NO_USE_COUPON = 0;

    /**
     * 当使用优惠券时，GOODS_ID(PACKAGE_ID)指定为1000
     */
    public static final int GOODS_ID_IN_USE_COUPON = 1000;
}
