package com.meda.opa.platform.alipay.service.impl;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.request.AlipaySystemOauthTokenRequest;
import com.alipay.api.request.AlipayUserInfoShareRequest;
import com.alipay.api.response.AlipaySystemOauthTokenResponse;
import com.alipay.api.response.AlipayUserInfoShareResponse;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.common.util.LogUtils;
import com.meda.opa.config.AlipayConfig;
import com.meda.opa.platform.alipay.service.AliPayService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

/**
 * 微信服务接口实现类
 *
 * @author Huangxiaodi
 * @date 2018/10/22
 */
@Service
public class AliPayServiceImpl implements AliPayService {

    private static final Logger log = LoggerFactory.getLogger(AliPayServiceImpl.class);

    private static AlipayClient alipayClient;

    public static void initAliPayClient() {
        if (alipayClient == null) {
            alipayClient = new DefaultAlipayClient(AlipayConfig.PAY_GATEWAY, AlipayConfig.APP_ID,
                    AlipayConfig.PAY_PRIVATE_KEY, "json", "UTF-8", AlipayConfig.PAY_PUBLIC_KEY, "RSA2");
        }
    }

    @Override
    public AlipaySystemOauthTokenResponse getAccessToken(String authCode) {
        Assert.hasText(authCode, "authCode参数不能为空");

        AlipaySystemOauthTokenRequest request = new AlipaySystemOauthTokenRequest();
        request.setCode(authCode);
        request.setGrantType("authorization_code");
        try {
            LogUtils.logInfo(log, "支付宝获取accessToken", LogConstant.RES_SUCCESS, "", 0, 0, "访问支付宝获取accessToken接口【成功】");
            return alipayClient.execute(request);
        } catch (Exception e) {
            LogUtils.logErrorWithException(log, "支付宝获取accessToken", LogConstant.RES_EXCEPTION, "", 0, 0, "访问支付宝获取accessToken接口【异常】", e);
        }
        return null;
    }

    @Override
    public AlipayUserInfoShareResponse getUserInfo(String accessToken) {
        Assert.hasText(accessToken, "accessToken参数不能为空");

        AlipayUserInfoShareRequest request = new AlipayUserInfoShareRequest();
        try {
            AlipayUserInfoShareResponse userInfo = alipayClient.execute(request, accessToken);
            LogUtils.logInfo(log, "支付宝获取用户信息", LogConstant.RES_SUCCESS, "", 0, 0, "访问支付宝获取用户信息接口【成功】");
            return userInfo;
        } catch (AlipayApiException e) {
            LogUtils.logErrorWithException(log, "支付宝获取用户信息", LogConstant.RES_EXCEPTION, "", 0, 0, "访问支付宝获取用户信息接口【异常】", e);
        }
        return null;
    }
}
