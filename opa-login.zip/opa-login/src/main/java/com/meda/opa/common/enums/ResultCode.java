package com.meda.opa.common.enums;

/**
 * 响应码枚举类
 *
 * @author Huangxiaodi
 * @date 2018/10/24
 */
public enum ResultCode {
    /**
     * 1000：成功
     */
    SUCCESS("1000", "成功"),
    /**
     * 1001：无效的客户端
     */
    INVALID_USER_AGENT("1001", "无效的客户端"),
    /**
     * 1002：微信获取accessToken失败
     */
    WECHAT_GET_ACCESS_TOKEN_FAIL("1002", "微信获取accessToken失败"),
    /**
     * 1003：微信获取用户信息失败
     */
    WECHAT_GET_USERINFO_FAIL("1003", "微信获取用户信息失败"),
    /**
     * 1004：支付宝获取accessToken失败
     */
    ALIPAY_GET_ACCESS_TOKEN_FAIL("1004", "支付宝获取accessToken失败"),
    /**
     * 1005：支付宝获取用户信息失败
     */
    ALIPAY_GET_USERINFO_FAIL("1005", "支付宝获取用户信息失败"),
    /**
     * 1006：QQ获取网页授权accessToken失败
     */
    QQ_GET_ACCESS_TOKEN_FROM_CODE_FAIL("1006", "QQ获取网页授权accessToken失败"),
    /**
     * 1007: QQ获取公众号accessToken失败
     */
    QQ_GET_MP_ACCESS_TOKEN_FAIL("1007", "QQ获取公众号accessToken失败"),
    /**
     * 1008：QQ获取用户信息失败
     */
    QQ_GET_USERINFO_FAIL("1008", "QQ获取用户信息失败"),
    /**
     * 1009：点歌页面重定向，参数错误
     */
    ORDER_SONG_REDIRECT_PARAM_ERROR("1009", "点歌页面重定向，参数错误"),
    /**
     * 1010：点歌页面重定向，微信获取支付accessToken失败
     */
    WECHAT_GET_PAY_ACCESS_TOKEN_FAIL("1010", "点歌页面重定向，微信获取支付accessToken失败"),
    /**
     * 1011：QQ网页授权多次回调异常
     */
    QQ_AUTH_MULTI_REDIRECT("1011", "QQ网页授权多次回调异常"),
    /**
     * 9998：服务器忙，请稍候重试
     */
    BUSY("9998", "服务器忙，请稍候重试"),
    /**
     * 9999：系统异常
     */
    SYSTEM_EXCEPTION("9999", "系统异常"),


    /**
     * 2001: 用户中心注册登录失败
     */
    REGISTER_LOGIN_FAIL("2001", "用户中心注册登录失败"),
    /**
     * 2002：用户中心响应异常
     */
    USER_CENTER_RESPONSE_FAIL("2002", "用户中心响应异常"),
    /**
     * 2003：产品服务异常
     */
    PRODUCT_SERVER_EXCEPTION("2003", "产品服务异常"),
    /**
     * 2004：用户不存在
     */
    USER_NOT_EXIST("2004", "用户不存在"),


    /**
     * 3001：获取支付金额失败
     */
    GET_PAY_AMOUNT_FAIL("3001", "获取支付金额失败"),
    /**
     * 3002：通知使用优惠券失败
     */
    NOTIFY_USE_COUPON_FAIL("3002", "通知使用优惠券失败"),


    /**
     * 4001：预支付失败
     */
    PRE_PAY_FAIL("4001", "预支付失败");


    private String code;

    private String description;

    ResultCode(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
