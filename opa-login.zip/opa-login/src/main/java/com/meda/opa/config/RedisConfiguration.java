package com.meda.opa.config;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * redis配置类
 *
 * @author Huangxiaodi
 * @date 2018/10/18
 */
@PropertySource(value = "classpath:application.properties")
@Configuration
public class RedisConfiguration {

    @Value("${redis.hosts}")
    private String hosts;

    @Value("${redis.maxWaitMillis}")
    private int maxWaitMillis;

    @Value("${redis.maxTotal}")
    private int maxTotal;

    @Value("${redis.maxIdle}")
    private int maxIdle;

    @Value("${redis.minIdle}")
    private int minIdle;

    @Value("${redis.timeout}")
    private int timeout;

    @Value("${redis.connectionTimeout}")
    private int connectionTimeout;

    @Value("${redis.soTimeout}")
    private int soTimeout;

    @Value("${redis.maxRedirections}")
    private int maxRedirections;

    /**
     * 非集群版pool配置
     *
     * @return
     */
    @Bean(name = "jedisPoolConfig")
    public JedisPoolConfig buildJedisPoolConfig() {
        JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
        jedisPoolConfig.setMaxIdle(maxIdle);
        jedisPoolConfig.setMinIdle(minIdle);
        jedisPoolConfig.setMaxTotal(maxTotal);
        jedisPoolConfig.setMaxWaitMillis(maxWaitMillis);
        return jedisPoolConfig;
    }

    /**
     * 构建非集群版pool
     *
     * @param jedisPoolConfig 非集群版pool配置实体
     * @return
     */
    @Bean(name = "jedisPool")
    public JedisPool buildJedisPool(JedisPoolConfig jedisPoolConfig) {
        String[] hostInfo = hosts.split(":");
        JedisPool jedisPool = new JedisPool(jedisPoolConfig, hostInfo[0], Integer.parseInt(hostInfo[1]), timeout);
        return jedisPool;
    }

    /**
     * 集群版pool配置
     *
     * @return
     */
    @ConditionalOnExpression("${redis.cluster}")
    @Bean(name = "genericObjectPoolConfig")
    public GenericObjectPoolConfig buildGenericObjectPoolConfig() {
        GenericObjectPoolConfig genericObjectPoolConfig = new GenericObjectPoolConfig();
        genericObjectPoolConfig.setMaxIdle(maxIdle);
        genericObjectPoolConfig.setMinIdle(minIdle);
        genericObjectPoolConfig.setMaxTotal(maxTotal);
        genericObjectPoolConfig.setMaxWaitMillis(maxWaitMillis);
        return genericObjectPoolConfig;
    }

    /**
     * 构建集群版pool
     *
     * @param genericObjectPoolConfig 集群版pool配置
     * @return
     */
    @ConditionalOnExpression("${redis.cluster}")
    @Bean(name = "jedisCluster")
    public JedisCluster buildJedisCluster(GenericObjectPoolConfig genericObjectPoolConfig) {
        String[] hostsArr = hosts.split(",");
        Set<HostAndPort> nodes = new LinkedHashSet<>(6);
        for (String hostStr : hostsArr) {
            String[] hostInfo = hostStr.split(":");
            HostAndPort hostAndPort = new HostAndPort(hostInfo[0], Integer.parseInt(hostInfo[1]));
            nodes.add(hostAndPort);
        }

        JedisCluster jedisCluster = new JedisCluster(nodes, connectionTimeout, soTimeout, maxRedirections, genericObjectPoolConfig);
        return jedisCluster;
    }
}
