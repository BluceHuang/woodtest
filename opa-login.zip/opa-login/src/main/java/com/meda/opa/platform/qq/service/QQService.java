package com.meda.opa.platform.qq.service;

import com.meda.opa.platform.qq.vo.QqAccessToken;
import com.meda.opa.platform.qq.vo.QqOAuthToken;
import com.meda.opa.platform.qq.vo.QqUserInfo;

/**
 * QQ服务接口
 *
 * @author Huangxiaodi
 * @date 2018/11/21
 */
public interface QQService {

    /**
     * 根据code获取用户的openid
     *
     * @param code qq的code
     * @return QqOAuthToken
     */
    QqOAuthToken getAccessTokenFromCode(String code);

    /**
     * 获取qq公众号的accessToken
     *
     * @return
     */
    QqAccessToken getPublicAccessToken();

    /**
     * 获取用户信息
     *
     * @param accessToken 公众号accessToken
     * @param openid      QQ用户openid
     * @return 用户信息
     */
    QqUserInfo getUserInfo(String accessToken, String openid);

}
