package com.meda.opa.common.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPool;

/**
 * redis工具类
 *
 * @author Huangxiaodi
 * @date 2018/10/18
 */
@Component(value = "redisUtils")
public class RedisUtils {
    @Autowired
    private JedisPool jedisPool;

    @Autowired(required = false)
    private JedisCluster jedisCluster;

    public void setString(String key, String value) {
        if (jedisCluster != null) {
            jedisCluster.set(key, value);
        } else {
            Jedis jedis = jedisPool.getResource();
            jedis.set(key, value);
            jedis.close();
        }
    }

    public String getString(String key) {
        String value;
        if (jedisCluster != null) {
            value = jedisCluster.get(key);
        } else {
            Jedis jedis = jedisPool.getResource();
            value = jedis.get(key);
            jedis.close();
        }

        return value;
    }

    public void setStringByte(byte[] key, byte[] value) {
        if (jedisCluster != null) {
            jedisCluster.set(key, value);
        } else {
            Jedis jedis = jedisPool.getResource();
            jedis.set(key, value);
            jedis.close();
        }
    }

    public byte[] getStringByte(byte[] key) {
        byte[] value;
        if (jedisCluster != null) {
            value = jedisCluster.get(key);
        } else {
            Jedis jedis = jedisPool.getResource();
            value = jedis.get(key);
            jedis.close();
        }

        return value;
    }

    public void setStringAndExpire(String key, int seconds, String value) {
        if (jedisCluster != null) {
            jedisCluster.setex(key, seconds, value);
        } else {
            Jedis jedis = jedisPool.getResource();
            jedis.setex(key, seconds, value);
            jedis.close();
        }
    }

    public void setExpire(String key, int seconds) {
        if (jedisCluster != null) {
            jedisCluster.expire(key, seconds);
        } else {
            Jedis jedis = jedisPool.getResource();
            jedis.expire(key, seconds);
            jedis.close();
        }
    }

    public void setExpireByte(byte[] key, int seconds) {
        if (jedisCluster != null) {
            jedisCluster.expire(key, seconds);
        } else {
            Jedis jedis = jedisPool.getResource();
            jedis.expire(key, seconds);
            jedis.close();
        }
    }

    public boolean chekcExistByStringKey(String key) {
        if (jedisCluster != null) {
            return jedisCluster.exists(key);
        } else {
            Jedis jedis = jedisPool.getResource();
            return jedis.exists(key);
        }
    }

}
