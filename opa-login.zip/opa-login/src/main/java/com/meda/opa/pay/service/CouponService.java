package com.meda.opa.pay.service;

import com.meda.opa.pay.vo.CouponRequest;
import com.meda.opa.pay.vo.coupon.ResponseInCoupon;

/**
 * 优惠券服务接口
 *
 * @author Huangxiaodi
 * @date 2018/10/23
 */
public interface CouponService {

    /**
     * 根据优惠券id调用优惠券查询接口查询优惠券信息
     *
     * @param couponId 优惠券id
     * @return
     */
    ResponseInCoupon getCouponInfoById(String couponId);

    /**
     * 根据优惠券id调用优惠券使用接口
     *
     * @param couponRequest 请求vo
     * @return
     */
    ResponseInCoupon useCoupon(CouponRequest couponRequest);
}
