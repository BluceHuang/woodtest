package com.meda.opa.pay.vo.machine;


import com.alibaba.fastjson.annotation.JSONField;

/**
 * 机器信息查询接口响应实体
 *
 * @author Huangxiaodi
 * @date 2018/10/24
 */
public class ResponseInQueryMachineInfo {

    private String mid;

    private String online;

    @JSONField(name = "cur_server_ip")
    private String curServerIp;

    private String location;

    @JSONField(name = "location_flag")
    private int locationFlag;

    @JSONField(name = "cur_login_uid")
    private String curLoginUid;

    @JSONField(name = "pay_switch")
    private String paySwitch;

    @JSONField(name = "exec_version")
    private String execVersion;

    @JSONField(name = "ui_version")
    private String uiVersion;

    @JSONField(name = "cur_songid")
    private String curSongId;

    @JSONField(name = "songware_type")
    private String songwareType;

    @JSONField(name = "operate_stime")
    private String operateStartTime;

    @JSONField(name = "operate_etime")
    private String operateEndTime;

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getOnline() {
        return online;
    }

    public void setOnline(String online) {
        this.online = online;
    }

    public String getCurServerIp() {
        return curServerIp;
    }

    public void setCurServerIp(String curServerIp) {
        this.curServerIp = curServerIp;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getLocationFlag() {
        return locationFlag;
    }

    public void setLocationFlag(int locationFlag) {
        this.locationFlag = locationFlag;
    }

    public String getCurLoginUid() {
        return curLoginUid;
    }

    public void setCurLoginUid(String curLoginUid) {
        this.curLoginUid = curLoginUid;
    }

    public String getPaySwitch() {
        return paySwitch;
    }

    public void setPaySwitch(String paySwitch) {
        this.paySwitch = paySwitch;
    }

    public String getExecVersion() {
        return execVersion;
    }

    public void setExecVersion(String execVersion) {
        this.execVersion = execVersion;
    }

    public String getUiVersion() {
        return uiVersion;
    }

    public void setUiVersion(String uiVersion) {
        this.uiVersion = uiVersion;
    }

    public String getCurSongId() {
        return curSongId;
    }

    public void setCurSongId(String curSongId) {
        this.curSongId = curSongId;
    }

    public String getSongwareType() {
        return songwareType;
    }

    public void setSongwareType(String songwareType) {
        this.songwareType = songwareType;
    }

    public String getOperateStartTime() {
        return operateStartTime;
    }

    public void setOperateStartTime(String operateStartTime) {
        this.operateStartTime = operateStartTime;
    }

    public String getOperateEndTime() {
        return operateEndTime;
    }

    public void setOperateEndTime(String operateEndTime) {
        this.operateEndTime = operateEndTime;
    }

    @Override
    public String toString() {
        return "ResponseInQueryMachineInfo{" +
                "mid='" + mid + '\'' +
                ", online='" + online + '\'' +
                ", curServerIp='" + curServerIp + '\'' +
                ", location='" + location + '\'' +
                ", locationFlag=" + locationFlag +
                ", curLoginUid='" + curLoginUid + '\'' +
                ", paySwitch='" + paySwitch + '\'' +
                ", execVersion='" + execVersion + '\'' +
                ", uiVersion='" + uiVersion + '\'' +
                ", curSongId='" + curSongId + '\'' +
                ", songwareType='" + songwareType + '\'' +
                ", operateStartTime='" + operateStartTime + '\'' +
                ", operateEndTime='" + operateEndTime + '\'' +
                '}';
    }
}
