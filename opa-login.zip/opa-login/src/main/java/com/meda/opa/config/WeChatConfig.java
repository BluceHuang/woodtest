package com.meda.opa.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 微信公众号配置类
 *
 * @author Huangxiaodi
 * @date 2018/11/12.
 */
@Component
public class WeChatConfig {

    /**
     * minishow公众号appId
     */
    public static String APP_ID;

    /**
     * minishow公众号appSecret
     */
    public static String APP_SECRET;

    /**
     * minishow支付公众号appId
     */
    public static String PAY_APP_ID;

    /**
     * minishow支付公众号appSecret
     */
    public static String PAY_APP_SECRET;

    /**
     * minishow支付公众号appKey
     */
    public static String PAY_KEY;

    /**
     * 微信回调uri
     */
    public static String AUTH_REDIRECT_URI;

    /**
     * 微信用户同意授权，获取code的API接口
     */
    public static String AUTH_URL;

    /**
     * 微信获取公众号唯一accessToken的API接口
     */
    public static String ACCESS_TOKEN_URL;

    /**
     * 微信通过code换取网页授权access_token的API接口
     */
    public static String ACCESS_TOKEN_UNFOLLOW_URL;

    /**
     * 微信拉取用户信息(需scope为 snsapi_userinfo)的API接口（用户必须关注公众号）
     */
    public static String USERINFO_URL;

    /**
     * 微信拉取用户信息(需scope为 snsapi_userinfo)的API接口（用户不必关注公众号）
     */
    public static String USERINFO_UNFOLLOW_URL;

    @Value("${weChat.appId}")
    public void setAppId(String appId) {
        APP_ID = appId;
    }

    @Value("${weChat.appSecret}")
    public void setAppSecret(String appSecret) {
        APP_SECRET = appSecret;
    }

    @Value("${weChat.pay.appId}")
    public void setPayAppId(String payAppId) {
        PAY_APP_ID = payAppId;
    }

    @Value("${weChat.pay.appSecret}")
    public void setPayAppSecret(String payAppSecret) {
        PAY_APP_SECRET = payAppSecret;
    }

    @Value("${weChat.pay.key}")
    public void setPayKey(String payKey) {
        PAY_KEY = payKey;
    }

    @Value("${weChat.authorize.redirect.uri}")
    public void setRedirectUri(String redirectUri) {
        AUTH_REDIRECT_URI = redirectUri;
    }

    @Value("${weChat.authorize.url}")
    public void setAuthorizeUrl(String authorizeUrl) {
        AUTH_URL = authorizeUrl;
    }

    @Value("${weChat.accessToken.url}")
    public void setAccessTokenUrl(String accessTokenUrl) {
        ACCESS_TOKEN_URL = accessTokenUrl;
    }

    @Value("${weChat.accessToken.unfollow.url}")
    public void setAccessTokenUnfollowUrl(String accessTokenUnfollowUrl) {
        ACCESS_TOKEN_UNFOLLOW_URL = accessTokenUnfollowUrl;
    }

    @Value("${weChat.userinfo.url}")
    public void setUserinfoUrl(String userinfoUrl) {
        USERINFO_URL = userinfoUrl;
    }

    @Value("${weChat.userinfo.unfollow.url}")
    public void setUserinfoUnfollowUrl(String userinfoUnfollowUrl) {
        USERINFO_UNFOLLOW_URL = userinfoUnfollowUrl;
    }
}
