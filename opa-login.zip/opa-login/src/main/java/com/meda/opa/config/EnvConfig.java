package com.meda.opa.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 全局环境配置类
 *
 * @author Huangxiaodi
 * @date 2018/10/31
 */
@Component
public class EnvConfig {

    public static boolean ENV_TEST;

    @Value("${minishow.debug}")
    public void setEnvTest(boolean envTest) {
        ENV_TEST = envTest;
    }
}
