package com.meda.opa.pay.service.impl;

import com.meda.opa.common.constant.HttpConstant;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.config.*;
import com.meda.opa.pay.service.MachineService;
import com.meda.opa.pay.service.OrderService;
import com.meda.opa.pay.vo.machine.ResponseInQueryMachineInfo;
import com.meda.opa.pay.vo.order.PrePayIdResponse;
import com.meda.opa.pay.vo.order.RechargeOrder;
import com.meda.opa.common.util.*;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.TreeMap;

/**
 * 订单服务接口实现类
 *
 * @author Huangxiaodi
 * @date 2018/10/24
 */
@Service
public class OrderServiceImpl implements OrderService {

    private static final Logger log = LoggerFactory.getLogger(OrderServiceImpl.class);

    @Autowired
    private MachineService machineService;

    @Override
    public Map<String, String> generateOrder(RechargeOrder order, int appType) {
        PrePayIdResponse prePayIdResponse = this.unifiedOrder(order, order.getMid(), appType);
        if (prePayIdResponse == null) {
            return null;
        }

        Map<String, String> resultMap = new TreeMap<>();
        if (StringUtils.isNotBlank(prePayIdResponse.getWxAppId())) {
            resultMap.put("appId", prePayIdResponse.getWxAppId());
            resultMap.put("package", "prepay_id=" + prePayIdResponse.getPrepayId());
            resultMap.put("timeStamp", prePayIdResponse.getTimeStamp());
            resultMap.put("nonceStr", prePayIdResponse.getNonceStr());
            resultMap.put("paySign", prePayIdResponse.getPaySign());
            if (StringUtils.isBlank(prePayIdResponse.getSignType())) {
                resultMap.put("signType", "MD5");
            } else {
                resultMap.put("signType", prePayIdResponse.getSignType());
            }
        } else if (StringUtils.isNotBlank(prePayIdResponse.getPrepayId())) {
            resultMap.put("appId", WeChatConfig.PAY_APP_ID);
            resultMap.put("package", "prepay_id=" + prePayIdResponse.getPrepayId());
            resultMap.put("timeStamp", String.valueOf((int) (System.currentTimeMillis() / 1000)));
            resultMap.put("nonceStr", RandomUtils.getRandomMixedStr(32));
            resultMap.put("signType", "MD5");
            try {
                String paySign = genPaySign(resultMap);
                resultMap.put("paySign", paySign);
                return resultMap;
            } catch (Exception e) {
                LogUtils.logErrorWithException(log, "生成微信支付订单-paySign生成", LogConstant.RES_EXCEPTION, "", order.getUid(), order.getMid(),
                        "paySign生成【失败】！", e);
                return null;
            }
        } else {
            return null;
        }

        return resultMap;
    }

    private String genPaySign(Map<String, String> orderParmaMap) throws Exception {
        StringBuffer keyValueBuffer = new StringBuffer();
        orderParmaMap.forEach((key, value) -> {
            if (StringUtils.isNotBlank(value)) {
                keyValueBuffer.append(key);
                keyValueBuffer.append("=");
                keyValueBuffer.append(value);
                keyValueBuffer.append("&");
            }
        });
        keyValueBuffer.append("key=");
        keyValueBuffer.append(WeChatConfig.PAY_KEY);

        LogUtils.logDebug(log, "生成微信支付订单-paySign生成", LogConstant.RES_NONE, "", 0, 0,
                "生产paySign中待加密字符串为：" + keyValueBuffer);
        return MD5Utils.md5(keyValueBuffer.toString()).toUpperCase();
    }

    @Override
    public PrePayIdResponse unifiedOrder(RechargeOrder order, int mid, int appType) {
        String url = null;
        if (appType == 1) {
            url = PayGatewayConfig.PAY_GATEWAY_GET_PREPAY_ID_APP1_URL;
        } else if (EnvConfig.ENV_TEST) {
            url = PayGatewayConfig.PAY_GATEWAY_GET_PREPAY_ID_TEST_URL;
        } else {
            ResponseInQueryMachineInfo machine = machineService.getByMid(String.valueOf(mid));
            if (machine != null && StringUtils.isNotBlank(machine.getExecVersion()) && machine.getExecVersion().compareToIgnoreCase(MinishowConfig.MACHINE_CAPI_VERSION) > 0) {
                url = PayGatewayConfig.PAY_GATEWAY_GET_PREPAY_ID_V3_URL;
            } else {
                url = PayGatewayConfig.PAY_GATEWAY_GET_PREPAY_ID_V2_URL;
            }
        }

        String orderJsonStr = FastJsonUtils.getBeanToJson(order);
        String verifyCode = DigestUtils.sha1Hex(orderJsonStr + PayGatewayConfig.SHA1_TOKEN);
        url = url.replace("verifyCode", verifyCode);

        LogUtils.logDebug(log, "生成微信支付订单-支付网关", LogConstant.RES_NONE, "", order.getUid(), order.getMid(),
                "请求url：" + url);
        LogUtils.logDebug(log, "生成微信支付订单-支付网关", LogConstant.RES_NONE, "", order.getUid(), order.getMid(),
                "访问获取预支付id接口，请求内容为：" + order);

        try {
            PrePayIdResponse responseEntity = HttpUtil.sendJsonDataAndGetResponseEntity(false, url, HttpConstant.REQUEST_METHOD_POST, order, PrePayIdResponse.class);
            LogUtils.logDebug(log, "生成微信支付订单-支付网关", LogConstant.RES_SUCCESS, "", order.getUid(), order.getMid(),
                    "访问获取预支付id接口【成功】，响应内容为：" + responseEntity);
            return responseEntity;
        } catch (Exception e) {
            LogUtils.logErrorWithException(log, "生成微信支付订单-支付网关", LogConstant.RES_EXCEPTION, "", order.getUid(), order.getMid(),
                    "访问获取预支付id接口【异常】", e);
            return null;
        }
    }
}
