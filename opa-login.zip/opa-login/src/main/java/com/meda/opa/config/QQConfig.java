package com.meda.opa.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * QQ配置类
 *
 * @author Huangxiaodi
 * @date 2018/11/23
 */
@Component
public class QQConfig {

    /**
     * 登录授权URL
     */
    public static String AUTH_URL;

    /**
     * 登录授权回调URL
     */
    public static String AUTH_REDIRECT_URI;

    /**
     * 获取网页授权accessToken url
     */
    public static String AUTH_ACCESS_TOKEN_URL;

    /**
     * 获取公众号accessToken url
     */
    public static String PUBLIC_ACCESS_TOKEN_URL;

    /**
     * 获取用户信息url
     */
    public static String GET_USER_INFO_URL;

    /**
     * 生活号appId
     */
    public static String APP_ID;

    /**
     * 生活号app Key
     */
    public static String APP_KEY;

    @Value("${qq.authorize.url}")
    public void setAuthUrl(String authUrl) {
        AUTH_URL = authUrl;
    }

    @Value("${qq.authorize.redirect.uri}")
    public void setAuthRedirectUrI(String authRedirectUrI) {
        AUTH_REDIRECT_URI = authRedirectUrI;
    }

    @Value("${qq.authorize.accessToken.url}")
    public void setAuthAccessTokenUrl(String authAccessTokenUrl) {
        AUTH_ACCESS_TOKEN_URL = authAccessTokenUrl;
    }

    @Value("${qq.public.accessToken.url}")
    public void setPublicAccessTokenUrl(String publicAccessTokenUrl) {
        PUBLIC_ACCESS_TOKEN_URL = publicAccessTokenUrl;
    }

    @Value("${qq.userinfo.url}")
    public void setGetUserInfoUrl(String getUserInfoUrl) {
        GET_USER_INFO_URL = getUserInfoUrl;
    }

    @Value("${qq.appId}")
    public void setAppId(String appId) {
        APP_ID = appId;
    }

    @Value("${qq.appKey}")
    public void setAppKey(String appKey) {
        APP_KEY = appKey;
    }
}
