package com.meda.opa.platform.alipay.service;

import com.alipay.api.response.AlipaySystemOauthTokenResponse;
import com.alipay.api.response.AlipayUserInfoShareResponse;

/**
 * 微信服务接口
 *
 * @author Huangxiaodi
 * @date 2018/10/18
 */
public interface AliPayService {

    /**
     * 根据auth_code获取用户的user_id和access_token
     *
     * @param authCode
     * @return AccessToken
     */
    AlipaySystemOauthTokenResponse getAccessToken(String authCode);

    /**
     * 根据access_token获取用户信息
     *
     * @param accessToken 支付宝accessToken
     * @return 用户信息
     */
    AlipayUserInfoShareResponse getUserInfo(String accessToken);
}
