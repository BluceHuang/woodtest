package com.meda.opa.pay.service.impl;

import com.meda.opa.common.constant.HttpConstant;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.common.enums.UserCenterRespCode;
import com.meda.opa.config.SystemConfig;
import com.meda.opa.pay.service.UserService;
import com.meda.opa.pay.vo.UserIdentification;
import com.meda.opa.pay.vo.user.RequestInGetUid;
import com.meda.opa.pay.vo.user.ResponseInGetUid;
import com.meda.opa.common.util.HttpUtil;
import com.meda.opa.common.util.LogUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * 用户服务接口实现类
 *
 * @author Huangxiaodi
 * @date 2018/10/22
 */
@Service
public class UserServiceImpl implements UserService {

    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    @Override
    public UserIdentification getUserIdentification(String uid) {
        RequestInGetUid requestEntity = new RequestInGetUid(uid);
        try {
            ResponseInGetUid responseEntity = HttpUtil.sendJsonDataAndGetResponseEntity(false, SystemConfig.UNO_QUERY_URL,
                    HttpConstant.REQUEST_METHOD_POST, requestEntity, ResponseInGetUid.class);
            if (UserCenterRespCode.SUCCESS.getResCode() == responseEntity.getStatus()) {
                LogUtils.logDebug(log, "用户中心校验", LogConstant.RES_SUCCESS, uid, 0, 0,
                        "用户中心校验【通过】，响应内容为：" + responseEntity);
                return new UserIdentification(responseEntity.getData().getUid(), responseEntity.getData().getUno());
            } else {
                LogUtils.logError(log, "用户中心校验", LogConstant.RES_FAIL, uid, 0, 0,
                        "用户中心校验【失败】，响应内容为：" + responseEntity);
                return null;
            }
        } catch (Exception e) {
            LogUtils.logErrorWithException(log, "用户中心校验", LogConstant.RES_EXCEPTION, uid, 0, 0,
                    "访问用户中心用户校验接口【异常】", e);
            return null;
        }
    }
}
