package com.meda.opa.common.constant;

/**
 * 用户中心常量类
 *
 * @author Huangxiaodi
 * @date 2018/11/23
 */
public class UserCenterConstant {

    /**
     * 与用户中心交互的验证密码，目前暂时为none
     */
    public static final String PWD_NONE = "none";

    /**
     * 指定类型是微信登录平台
     */
    public static final String TYPE_WX = "wx";

    /**
     * 指定类型是QQ登录平台
     */
    public static final String TYPE_QQ = "qq";

    /**
     * 指定类型是支付宝登录平台
     */
    public static final String TYPE_ALIPAY = "zfb";

    /**
     * 性别：男
     */
    public static final String SEX_MALE = "1";

    /**
     * 性别：女
     */
    public static final String SEX_FEMALE = "2";

    /**
     * 性别：未知
     */
    public static final String SEX_UNKNOWN = "0";

    /**
     * 微信用户信息额外说明字段
     */
    public static final String EX_WX = "wx info";

    /**
     * QQ用户信息额外说明字段
     */
    public static final String EX_QQ = "qq info";

    /**
     * 支付宝用户信息额外说明字段
     */
    public static final String EX_ALIPAY = "zfb info";

}
