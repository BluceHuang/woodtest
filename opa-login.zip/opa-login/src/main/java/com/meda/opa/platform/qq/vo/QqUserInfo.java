package com.meda.opa.platform.qq.vo;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * QQ用户信息查询接口对应的响应vo
 *
 * @author Huangxiaodi
 * @date 2018/11/21
 */
public class QqUserInfo {

    private String nickname;

    private String sex;

    @JSONField(name = "headimgurl")
    private String headImgUrl;

    @JSONField(name = "unionid")
    private String unionId;

    private String country;

    private String province;

    private String city;

    @JSONField(name = "openid")
    private String openId;

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getHeadImgUrl() {
        return headImgUrl;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public String getUnionId() {
        return unionId;
    }

    public void setUnionId(String unionId) {
        this.unionId = unionId;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    @Override
    public String toString() {
        return "QqUserInfo{" +
                "nickname='" + nickname + '\'' +
                ", sex='" + sex + '\'' +
                ", headImgUrl='" + headImgUrl + '\'' +
                ", unionId='" + unionId + '\'' +
                ", country='" + country + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", openId='" + openId + '\'' +
                '}';
    }
}
