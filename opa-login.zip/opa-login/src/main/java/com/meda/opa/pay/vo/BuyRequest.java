package com.meda.opa.pay.vo;

import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;

/**
 * 预支付请求体
 *
 * @author Huangxiaodi
 * @date 2018/11/2
 */
public class BuyRequest {

    @NotNull(message = "openid不能为空")
    private String openid;

    @NotNull(message = "uid不能为空")
    private String uid;

    @NotNull(message = "uno不能为空")
    @Range(min = 1)
    private Integer uno;

    @NotNull(message = "mid不能为空")
    @Range(min = 1)
    private Integer mid;

    @NotNull(message = "packet_id不能为空")
    private Integer packet_id;

    private Integer price;

    @NotNull(message = "cost_mode不能为空")
    private Integer cost_mode;

    @NotNull(message = "time_seconds不能为空")
    private Integer time_seconds;

    private Integer app_type = 0;

    @NotNull(message = "source不能为空")
    private Integer source;

    public BuyRequest() {

    }

    public BuyRequest(@NotNull(message = "uid不能为空") String uid, @NotNull(message = "uno不能为空") @Range(min = 1) Integer uno,
                      @NotNull(message = "mid不能为空") @Range(min = 1) Integer mid, @NotNull(message = "packet_id不能为空") Integer packet_id,
                      @NotNull(message = "cost_mode不能为空") Integer cost_mode, @NotNull(message = "time_seconds不能为空") Integer time_seconds,
                      @NotNull(message = "source不能为空") Integer source) {
        this.uid = uid;
        this.uno = uno;
        this.mid = mid;
        this.packet_id = packet_id;
        this.cost_mode = cost_mode;
        this.time_seconds = time_seconds;
        this.source = source;
    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public Integer getUno() {
        return uno;
    }

    public void setUno(Integer uno) {
        this.uno = uno;
    }

    public Integer getMid() {
        return mid;
    }

    public void setMid(Integer mid) {
        this.mid = mid;
    }

    public Integer getPacket_id() {
        return packet_id;
    }

    public void setPacket_id(Integer packet_id) {
        this.packet_id = packet_id;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getCost_mode() {
        return cost_mode;
    }

    public void setCost_mode(Integer cost_mode) {
        this.cost_mode = cost_mode;
    }

    public Integer getTime_seconds() {
        return time_seconds;
    }

    public void setTime_seconds(Integer time_seconds) {
        this.time_seconds = time_seconds;
    }

    public Integer getApp_type() {
        return app_type;
    }

    public void setApp_type(Integer app_type) {
        this.app_type = app_type;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    @Override
    public String toString() {
        return "BuyRequest{" +
                "openid='" + openid + '\'' +
                ", uid='" + uid + '\'' +
                ", uno=" + uno +
                ", mid=" + mid +
                ", packet_id=" + packet_id +
                ", price=" + price +
                ", cost_mode=" + cost_mode +
                ", time_seconds=" + time_seconds +
                ", app_type=" + app_type +
                ", source=" + source +
                '}';
    }
}
