package com.meda.opa.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Http请求配置类
 *
 * @author Huangxiaodi
 * @date 2018/11/16
 */
@Component
public class HttpConfig {

    public static int CONNECTION_TIMEOUT;

    public static int READ_TIMEOUT;

    @Value("${http.connection.timeout}")
    public void setConnectionTimeout(int connectionTimeout) {
        CONNECTION_TIMEOUT = connectionTimeout;
    }

    @Value("${http.read.timeout}")
    public void setReadTimeout(int readTimeout) {
        READ_TIMEOUT = readTimeout;
    }
}
