package com.meda.opa.pay.service.impl;

import com.meda.opa.common.constant.HttpConstant;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.config.SystemConfig;
import com.meda.opa.pay.service.MachineService;
import com.meda.opa.pay.vo.machine.RequestInQueryMachineInfo;
import com.meda.opa.pay.vo.machine.ResponseInQueryMachineInfo;
import com.meda.opa.common.util.HttpUtil;
import com.meda.opa.common.util.LogUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * 机器服务接口实现类
 *
 * @author Huangxiaodi
 * @date 2018/10/24
 */
@Service
public class MachineServiceImpl implements MachineService {

    private static final Logger log = LoggerFactory.getLogger(MachineServiceImpl.class);

    @Override
    public ResponseInQueryMachineInfo getByMid(String mid) {
        RequestInQueryMachineInfo requestEntity = new RequestInQueryMachineInfo(mid);

        try {
            ResponseInQueryMachineInfo responseEntity = HttpUtil.sendJsonDataAndGetResponseEntity(false, SystemConfig.GET_MACHINE_INFO_URL, HttpConstant.REQUEST_METHOD_POST,
                    requestEntity, ResponseInQueryMachineInfo.class);
            LogUtils.logDebug(log, "机器信息查询", LogConstant.RES_SUCCESS, "", 0, Integer.parseInt(mid),
                    "访问机器信息查询接口【成功】，响应内容为：" + responseEntity);
            return responseEntity;
        } catch (Exception e) {
            LogUtils.logErrorWithException(log, "机器信息查询", LogConstant.RES_EXCEPTION, "", 0, Integer.parseInt(mid),
                    "访问查询机器信息接口【异常】", e);
            return null;
        }
    }

}
