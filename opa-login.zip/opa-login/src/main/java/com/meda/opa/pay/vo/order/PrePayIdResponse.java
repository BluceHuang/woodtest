package com.meda.opa.pay.vo.order;


import com.alibaba.fastjson.annotation.JSONField;

/**
 * 支付网关获取PrePayId接口响应实体
 *
 * @author Huangxiaodi
 * @date 2018/10/24
 */
public class PrePayIdResponse {

    private String wxAppId;

    @JSONField(name = "prepay_id")
    private String prepayId;

    private String timeStamp;

    private String nonceStr;

    private String signType;

    private String paySign;

    public String getWxAppId() {
        return wxAppId;
    }

    public void setWxAppId(String wxAppId) {
        this.wxAppId = wxAppId;
    }

    public String getPrepayId() {
        return prepayId;
    }

    public void setPrepayId(String prepayId) {
        this.prepayId = prepayId;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getNonceStr() {
        return nonceStr;
    }

    public void setNonceStr(String nonceStr) {
        this.nonceStr = nonceStr;
    }

    public String getSignType() {
        return signType;
    }

    public void setSignType(String signType) {
        this.signType = signType;
    }

    public String getPaySign() {
        return paySign;
    }

    public void setPaySign(String paySign) {
        this.paySign = paySign;
    }

    @Override
    public String toString() {
        return "PrePayIdResponse{" +
                "wxAppId='" + wxAppId + '\'' +
                ", prepayId='" + prepayId + '\'' +
                ", timeStamp='" + timeStamp + '\'' +
                ", nonceStr='" + nonceStr + '\'' +
                ", signType='" + signType + '\'' +
                ", paySign='" + paySign + '\'' +
                '}';
    }
}
