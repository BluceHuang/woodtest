package com.meda.opa.login.service.auth.impl;

import com.meda.opa.common.constant.UserCenterConstant;
import com.meda.opa.common.constant.WeChatConstant;
import com.meda.opa.common.enums.ResultCode;
import com.meda.opa.config.MinishowConfig;
import com.meda.opa.config.WeChatConfig;
import com.meda.opa.login.dto.LoginOrRegisterResult;
import com.meda.opa.login.vo.EmptyInfo;
import com.meda.opa.login.vo.ProductInfo;
import com.meda.opa.login.vo.UserRegisterReq;
import com.meda.opa.platform.wechat.service.WeChatService;
import com.meda.opa.platform.wechat.vo.OAuthToken;
import com.meda.opa.platform.wechat.vo.ResponseInGetUserinfo;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

/**
 * 微信用户授权登录服务实现类
 *
 * @author Huangxiaodi
 * @date 2018/11/19.
 */
@Service("weChatAuthService")
public class WeChatAuthServiceImpl extends AbstractAuthServiceImpl {

    private static Logger log = LoggerFactory.getLogger(WeChatAuthServiceImpl.class);

    @Autowired
    private WeChatService weChatService;

    @Override
    public String getThirdPartyAuthoriseUrl(ProductInfo productInfo) {
        String arg = assembleQueryStringFromProductInfo(productInfo);
        String uri = WeChatConfig.AUTH_REDIRECT_URI.replace("MID", arg);
        // 微信授权链接
        String url = WeChatConfig.AUTH_URL
                .replace("appId", WeChatConfig.APP_ID)
                .replace("redirectUri", uri)
                .replace("scopeStr", WeChatConstant.SCOPE_USERINFO);

        return url;
    }

    @Override
    public LoginOrRegisterResult getAuth(String code, String arg) {
        Assert.hasText(code, "code参数不能为空");
        Assert.hasText(arg, "arg参数不能为空");

        // 获取微信用户openid和网页授权Access_token
        OAuthToken authToken = weChatService.getAccessToken(WeChatConfig.APP_ID, WeChatConfig.APP_SECRET, code);
        if (StringUtils.isNotBlank(authToken.getErrMsg())) {
            return new LoginOrRegisterResult(ResultCode.WECHAT_GET_ACCESS_TOKEN_FAIL.getCode());
        }
        // 获取微信用户信息
        ResponseInGetUserinfo responseInGetUserinfo = weChatService.getUserinfo(authToken.getAccessToken(), authToken.getOpenId());
        if (responseInGetUserinfo == null) {
            return new LoginOrRegisterResult(ResultCode.WECHAT_GET_USERINFO_FAIL.getCode());
        }
        ProductInfo productInfo = setProductInfo(arg);
        productInfo.setInfo(new EmptyInfo());
        UserRegisterReq.WeChatUserInfo userInfo = setUserInfo(responseInGetUserinfo);

        UserRegisterReq userRegisterReq = new UserRegisterReq();
        userRegisterReq.setProduct(productInfo);
        userRegisterReq.setUsrinfo(userInfo);

        if (StringUtils.isNotBlank(authToken.getUnionId())) {
            userRegisterReq.setLoginId(authToken.getUnionId());
        } else {
            userRegisterReq.setLoginId(authToken.getOpenId());
        }
        userRegisterReq.setType(UserCenterConstant.TYPE_WX);
        userRegisterReq.setPwd(UserCenterConstant.PWD_NONE);

        Integer mid = Integer.parseInt(productInfo.getMid());
        // 调用用户中心注册登录接口
        LoginOrRegisterResult loginAndRegisterResult = loginOrRegisterFromUserCenter(userRegisterReq, mid);
        loginAndRegisterResult.setCouponId(productInfo.getCoupon_id());
        loginAndRegisterResult.setMid(mid);
        loginAndRegisterResult.setUnionId(authToken.getUnionId());
        return loginAndRegisterResult;
    }

    /**
     * 根据微信查询用户信息接口返回的用户信息vo封装为用户中心请求json的usrinfo节点
     *
     * @param weChatUserinfo 微信查询用户信息接口返回的vo
     * @return UserInfo
     */
    private UserRegisterReq.WeChatUserInfo setUserInfo(ResponseInGetUserinfo weChatUserinfo) {
        UserRegisterReq.WeChatUserInfo userInfo = new UserRegisterReq.WeChatUserInfo();
        userInfo.setBindWx(weChatUserinfo.getOpenId());
        userInfo.setCity(weChatUserinfo.getCity());
        userInfo.setCountry(weChatUserinfo.getCountry());
        userInfo.setEx(UserCenterConstant.EX_WX);
        userInfo.setImageUrl(getHugeSizeHeadImgUrl(weChatUserinfo.getHeadImgUrl()));
        userInfo.setName(weChatUserinfo.getNickname());
        userInfo.setProvince(weChatUserinfo.getProvince());
        userInfo.setSex(weChatUserinfo.getSex());

        return userInfo;
    }

    /**
     * 将小头像处理为大头像
     *
     * @param headImgUrl 小头像原始url
     * @return
     */
    private String getHugeSizeHeadImgUrl(String headImgUrl) {
        if (StringUtils.isBlank(headImgUrl)) {
            return MinishowConfig.DEFAULT_HEADIMG_URL;
        }
        return headImgUrl.replaceFirst("(.*/)([^/]*)", "$1" + "0");
    }
}
