package com.meda.opa.pay.vo;

/**
 * 用户标识vo
 *
 * @author Huangxiaodi
 * @date 2018/11/8
 */
public class UserIdentification {

    private String uid;

    private int uno;

    public UserIdentification() {

    }

    public UserIdentification(String uid, int uno) {
        this.uid = uid;
        this.uno = uno;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public int getUno() {
        return uno;
    }

    public void setUno(int uno) {
        this.uno = uno;
    }

    @Override
    public String toString() {
        return "UserIdentification{" +
                "uid='" + uid + '\'' +
                ", uno=" + uno +
                '}';
    }
}
