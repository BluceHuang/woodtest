package com.meda.opa.common.util;

import com.meda.opa.common.constant.HttpConstant;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.config.HttpConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.*;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.Map;

/**
 * Http工具类
 *
 * @author Huangxiaodi
 * @date 2018/8/30.
 */
public class HttpUtil {

    private static final Logger log = LoggerFactory.getLogger(HttpUtil.class);

    /**
     * 不带请求体直接访问服务端，服务端返回文本
     *
     * @param connection http或https连接
     * @return
     */
    public static String sendWithoutData(URLConnection connection) throws Exception {
        HttpURLConnection httpUrlConnection = null;
        try {
            httpUrlConnection = (HttpURLConnection) connection;
            httpUrlConnection.connect();
            StringBuffer sb = getResponseBodyOfText(httpUrlConnection);
            return sb.toString();
        } catch (Exception e) {
            throw new Exception(e);
        } finally {
            if (httpUrlConnection != null) {
                httpUrlConnection.disconnect();
            }
        }
    }

    /**
     * 发送JSON格式数据，服务端返回文本
     *
     * @param connection http或https连接
     * @param jsonData   json格式数据
     * @return
     */
    public static String sendJsonData(URLConnection connection, String jsonData) throws Exception {
        HttpURLConnection httpUrlConnection = null;
        try {
            httpUrlConnection = (HttpURLConnection) connection;
            httpUrlConnection.connect();
            DataOutputStream out = new DataOutputStream(
                    httpUrlConnection.getOutputStream());
            out.write(jsonData.getBytes("UTF-8"));
            out.flush();
            out.close();
            StringBuffer sb = getResponseBodyOfText(httpUrlConnection);
            return sb.toString();
        } catch (Exception e) {
            throw new Exception(e);
        } finally {
            if (httpUrlConnection != null) {
                httpUrlConnection.disconnect();
            }
        }
    }

    /**
     * 发送JSON格式数据，并将服务端返回内容封装为响应实体
     *
     * @param ssl           是否开启https协议
     * @param urlStr        请求url
     * @param requestType   请求类型
     * @param requestEntity 请求实体
     * @param responseClazz 响应实体class
     * @param <T>
     * @return
     */
    public static <T> T sendJsonDataAndGetResponseEntity(boolean ssl, String urlStr, String requestType,
                                                         Object requestEntity, Class<T> responseClazz) throws Exception {
        String jsonStr = FastJsonUtils.getBeanToJson(requestEntity);

        LogUtils.logDebug(log, "", LogConstant.RES_NONE, "", 0, 0, "请求接口的json字符串为：" + jsonStr);

        HttpURLConnection connection = null;
        try {
            if (ssl) {
                connection = getHttpsConnection(urlStr, requestType, HttpConstant.CONTENT_TYPE_JSON);
            } else {
                connection = getHttpConnection(urlStr, requestType, HttpConstant.CONTENT_TYPE_JSON);
            }
            connection.connect();

            DataOutputStream out = new DataOutputStream(connection.getOutputStream());
            out.write(jsonStr.getBytes("UTF-8"));
            out.flush();
            out.close();

            StringBuffer responseJsonStr = getResponseBodyOfText(connection);

            LogUtils.logDebug(log, "", LogConstant.RES_SUCCESS, "", 0, 0, "接口返回json字符串为：" + responseJsonStr);

            return FastJsonUtils.getJsonToBean(responseJsonStr.toString(), responseClazz);
        } catch (Exception e) {
            throw new Exception(e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    /**
     * 不带请求体直接访问服务端，并将服务端返回内容封装为响应实体
     *
     * @param ssl           是否开启https协议
     * @param urlStr        请求url
     * @param requestType   请求类型
     * @param responseClazz 响应实体class
     * @param <T>
     * @return
     */
    public static <T> T sendWithoutDataAndGetResponseEntity(boolean ssl, String urlStr, String requestType, Class<T> responseClazz)
            throws Exception {
        HttpURLConnection connection = null;
        try {
            if (ssl) {
                connection = getHttpsConnection(urlStr, requestType, HttpConstant.CONTENT_TYPE_DEFAULT);
            } else {
                connection = getHttpConnection(urlStr, requestType, HttpConstant.CONTENT_TYPE_DEFAULT);
            }
            connection.connect();

            StringBuffer responseJsonStr = getResponseBodyOfText(connection);
            LogUtils.logDebug(log, "", LogConstant.RES_NONE, "", 0, 0, "接口返回json字符串为：" + responseJsonStr);
            return FastJsonUtils.getJsonToBean(responseJsonStr.toString(), responseClazz);
        } catch (Exception e) {
            throw new Exception(e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    /**
     * 携带请求头访问服务端，服务端返回文本内容
     *
     * @param connection
     * @param headerMap
     * @return
     * @throws Exception
     */
    public static String sendWithHeaders(URLConnection connection, Map<String, String> headerMap) throws Exception {
        HttpURLConnection httpUrlConnection = null;
        try {
            httpUrlConnection = (HttpURLConnection) connection;
            for (Map.Entry<String, String> entry : headerMap.entrySet()) {
                httpUrlConnection.addRequestProperty(entry.getKey(), entry.getValue());
            }
            httpUrlConnection.connect();
            StringBuffer sb = getResponseBodyOfText(httpUrlConnection);
            return sb.toString();
        } catch (Exception e) {
            throw new Exception(e);
        } finally {
            if (httpUrlConnection != null) {
                httpUrlConnection.disconnect();
            }
        }
    }

    /**
     * 携带请求头以及key-value形式数据访问服务端，服务端返回文本内容
     *
     * @param connection
     * @param headerMap
     * @param postEntityList
     * @return
     * @throws Exception
     */
    public static String sendWithHeadersAndBody(URLConnection connection, Map<String, String> headerMap, List<PostEntity> postEntityList) throws Exception {
        HttpURLConnection httpUrlConnection = null;
        try {
            httpUrlConnection = (HttpURLConnection) connection;
            for (Map.Entry<String, String> entry : headerMap.entrySet()) {
                httpUrlConnection.addRequestProperty(entry.getKey(), entry.getValue());
            }

            StringBuffer bodyParamBuffer = new StringBuffer();
            postEntityList.forEach(postEntity -> {
                bodyParamBuffer.append(postEntity.getKey());
                bodyParamBuffer.append("=");
                bodyParamBuffer.append(postEntity.getValue());
                bodyParamBuffer.append("&");
            });
            StringBuffer fixedBodyParamBuffer = bodyParamBuffer.deleteCharAt(bodyParamBuffer.length() - 1);
            DataOutputStream out = new DataOutputStream(
                    httpUrlConnection.getOutputStream());
            out.write(fixedBodyParamBuffer.toString().getBytes("UTF-8"));
            out.flush();
            out.close();

            StringBuffer response = getResponseBodyOfText(httpUrlConnection);
            return response.toString();
        } catch (Exception e) {
            throw new Exception(e);
        } finally {
            if (httpUrlConnection != null) {
                httpUrlConnection.disconnect();
            }
        }
    }

    /**
     * 读取服务端的响应文本
     *
     * @param httpUrlConnection
     * @return
     * @throws IOException
     */
    private static StringBuffer getResponseBodyOfText(HttpURLConnection httpUrlConnection) throws IOException {
        //读取响应
        BufferedReader reader = new BufferedReader(new InputStreamReader(httpUrlConnection.getInputStream()));
        String lines;
        StringBuffer sb = new StringBuffer();
        while ((lines = reader.readLine()) != null) {
            lines = new String(lines.getBytes(), "UTF-8");
            sb.append(lines);
        }
        reader.close();
        httpUrlConnection.disconnect();
        return sb;
    }

    /**
     * 获取http连接对象
     *
     * @param urlStr      url
     * @param requestType 请求类型，get 或者 post
     * @param contentType 请求数据类型
     * @return
     * @throws Exception
     */
    public static HttpURLConnection getHttpConnection(String urlStr, String requestType, String contentType) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection connection = (HttpURLConnection) url
                .openConnection();
        connection.setDoOutput(true);
        connection.setDoInput(true);
        connection.setRequestMethod(requestType);
        connection.setUseCaches(false);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("Content-Type",
                contentType);
        connection.setConnectTimeout(HttpConfig.CONNECTION_TIMEOUT);
        connection.setReadTimeout(HttpConfig.READ_TIMEOUT);
        return connection;
    }

    /**
     * 获取https连接对象
     *
     * @param urlStr      url
     * @param requestType 请求类型，get 或者 post
     * @param contentType 请求数据类型
     * @return
     * @throws Exception
     */
    public static HttpsURLConnection getHttpsConnection(String urlStr, String requestType, String contentType) throws Exception {
        SSLContext sslContext = SSLContext.getInstance("SSL");
        sslContext.init(null, new TrustManager[]{new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            }


            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType)


                    throws CertificateException {
            }


            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }
        }}, new SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
        HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String arg0, SSLSession arg1) {
                return true;
            }
        });

        URL url = new URL(null, urlStr, new sun.net.www.protocol.https.Handler());
        HttpsURLConnection httpsURLConnection = (HttpsURLConnection) url.openConnection();
        httpsURLConnection.setSSLSocketFactory(sslContext.getSocketFactory());

        httpsURLConnection.setDoInput(true);
        httpsURLConnection.setDoOutput(true);
        httpsURLConnection.setRequestMethod(requestType);
        httpsURLConnection.setUseCaches(false);
        httpsURLConnection.setInstanceFollowRedirects(true);
        httpsURLConnection.setRequestProperty("Content-Type",
                contentType);
        httpsURLConnection.setConnectTimeout(HttpConfig.CONNECTION_TIMEOUT);
        httpsURLConnection.setReadTimeout(HttpConfig.READ_TIMEOUT);
        return httpsURLConnection;
    }


    public static class PostEntity {
        private String key;

        private String value;

        public PostEntity() {

        }

        public PostEntity(String key, String value) {
            this.key = key;
            this.value = value;
        }

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

}
