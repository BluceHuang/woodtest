package com.meda.opa.platform.qq.service.impl;

import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.common.util.FastJsonUtils;
import com.meda.opa.common.util.HttpUtils;
import com.meda.opa.common.util.LogUtils;
import com.meda.opa.config.QQConfig;
import com.meda.opa.platform.qq.constant.QQErrorCode;
import com.meda.opa.platform.qq.service.QQService;
import com.meda.opa.platform.qq.vo.QqAccessToken;
import com.meda.opa.platform.qq.vo.QqOAuthToken;
import com.meda.opa.platform.qq.vo.QqUserInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

/**
 * 微信服务接口实现类
 *
 * @author Huangxiaodi
 * @date 2018/10/22
 */
@Service
public class QQServiceImpl implements QQService {

    private static final Logger log = LoggerFactory.getLogger(QQServiceImpl.class);

    /**
     * 获取QQ网页授权的access_token
     *
     * @return access_token
     */
    @Override
    public QqOAuthToken getAccessTokenFromCode(String code) {
        Assert.hasText(code, "code参数不能为空");

        String url = QQConfig.AUTH_ACCESS_TOKEN_URL
                .replace("appId", QQConfig.APP_ID)
                .replace("appSecret", QQConfig.APP_KEY)
                .replace("CODE", code);
        try {
            String response = HttpUtils.doGet(url);
            QqOAuthToken qqOAuthToken = FastJsonUtils.getJsonToBean(response, QqOAuthToken.class);
            if (QQErrorCode.SUCCESS == qqOAuthToken.getErrCode()) {
                LogUtils.logDebug(log, "QQ通过code获取网页授权access_token", LogConstant.RES_SUCCESS, "", 0, 0,
                        "QQ通过code获取网页授权access_token【成功】，响应内容为：" + qqOAuthToken);
            } else {
                LogUtils.logError(log, "QQ通过code获取网页授权access_token", LogConstant.RES_FAIL, "", 0, 0,
                        "QQ通过code获取网页授权access_token【失败】，响应内容为：" + qqOAuthToken);
            }
            return qqOAuthToken;
        } catch (Exception e) {
            LogUtils.logErrorWithException(log, "QQ通过code获取网页授权access_token", LogConstant.RES_EXCEPTION, "", 0, 0,
                    "QQ通过code获取网页授权access_token【异常】", e);
            return null;
        }
    }

    @Override
    public QqAccessToken getPublicAccessToken() {
        String url = QQConfig.PUBLIC_ACCESS_TOKEN_URL
                .replace("appId", QQConfig.APP_ID)
                .replace("appSecret", QQConfig.APP_KEY);

        try {
            String response = HttpUtils.doGet(url);
            QqAccessToken qqAccessToken = FastJsonUtils.getJsonToBean(response, QqAccessToken.class);


            if (QQErrorCode.SUCCESS == qqAccessToken.getErrCode()) {
                LogUtils.logDebug(log, "QQ获取公众号access_token", LogConstant.RES_SUCCESS, "", 0, 0,
                        "QQ获取公众号access_token【成功】，响应内容为：" + qqAccessToken);
            } else {
                LogUtils.logError(log, "QQ获取公众号access_token", LogConstant.RES_FAIL, "", 0, 0,
                        "QQ获取公众号access_token【失败】，响应内容为：" + qqAccessToken);
            }
            return qqAccessToken;
        } catch (Exception e) {
            LogUtils.logErrorWithException(log, "QQ获取公众号access_token", LogConstant.RES_EXCEPTION, "", 0, 0,
                    "QQ获取公众号access_token【异常】", e);
            return null;
        }
    }

    @Override
    public QqUserInfo getUserInfo(String mpAccessToken, String openid) {
        Assert.hasText(mpAccessToken, "accessToken参数不能为空");
        Assert.hasText(openid, "openid参数不能为空");

        String infoUrl = QQConfig.GET_USER_INFO_URL
                .replace("ACCESS_TOKEN", mpAccessToken)
                .replace("openId", openid);
        try {
            String response = HttpUtils.doGet(infoUrl);
            QqUserInfo qqUserInfo = FastJsonUtils.getJsonToBean(response, QqUserInfo.class);
            LogUtils.logDebug(log, "QQ获取用户信息", LogConstant.RES_SUCCESS, "", 0, 0, "QQ获取用户信息【成功】，响应内容为：" + qqUserInfo);
            return qqUserInfo;
        } catch (Exception e) {
            LogUtils.logErrorWithException(log, "QQ获取用户信息", LogConstant.RES_EXCEPTION, "", 0, 0, "QQ获取用户信息【异常】", e);
            return null;
        }
    }

}
