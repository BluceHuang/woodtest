package com.meda.opa.common.constant;

/**
 * http常量
 *
 * @author Huangxiaodi
 * @date 2018/10/22
 */
public class HttpConstant {

    public static final String REQUEST_METHOD_GET = "GET";

    public static final String REQUEST_METHOD_POST = "POST";

    public static final String REQUEST_METHOD_PUT = "PUT";

    public static final String CONTENT_TYPE_DEFAULT = "application/x-www-form-urlencoded";

    public static final String CONTENT_TYPE_JSON = "application/json";

    public static final String REQUEST_TYPE_XML_HTTP_REQUEST = "XMLHttpRequest";

    public static final String HEADER_X_REQUESTED_WITH = "X-Requested-With";

    public static final String HEADER_ACCEPT = "Accept";

    public static final String HEADER_USER_AGENT = "user-agent";
}
