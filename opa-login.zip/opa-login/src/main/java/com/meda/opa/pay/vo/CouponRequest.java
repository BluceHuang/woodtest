package com.meda.opa.pay.vo;

import javax.validation.constraints.NotNull;

/**
 * 使用优惠券请求vo
 *
 * @author Huangxiaodi
 * @date 2018/11/12
 */
public class CouponRequest {

    @NotNull(message = "coupon_id不能为空")
    private String coupon_id;

    @NotNull(message = "openid不能为空")
    private String openid;

    @NotNull(message = "uid不能为空")
    private String uid;

    @NotNull(message = "uno不能为空")
    private Integer uno;

    @NotNull(message = "mid不能为空")
    private Integer mid;

    @NotNull(message = "source不能为空")
    private Integer source;

    @NotNull(message = "cost_mode不能为空")
    private Integer cost_mode;

    @NotNull(message = "time_seconds不能为空")
    private Integer time_seconds;

    public String getCoupon_id() {
        return coupon_id;
    }

    public void setCoupon_id(String coupon_id) {
        this.coupon_id = coupon_id;
    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public Integer getUno() {
        return uno;
    }

    public void setUno(Integer uno) {
        this.uno = uno;
    }

    public Integer getMid() {
        return mid;
    }

    public void setMid(Integer mid) {
        this.mid = mid;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public Integer getCost_mode() {
        return cost_mode;
    }

    public void setCost_mode(Integer cost_mode) {
        this.cost_mode = cost_mode;
    }

    public Integer getTime_seconds() {
        return time_seconds;
    }

    public void setTime_seconds(Integer time_seconds) {
        this.time_seconds = time_seconds;
    }
}
