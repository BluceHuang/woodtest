package com.meda.opa.common.constant;

/**
 * 二维码常量类
 *
 * @author Huangxiaodi
 * @date 2018/11/20
 */
public class QRCodeConstant {

    /**
     * 支付宝扫码时携带的user agent信息
     */
    public static final String USER_AGENT_ALIPAY = "AlipayClient";

    /**
     * 微信扫码时携带的user agent信息
     */
    public static final String USER_AGENT_WECHAT = "MicroMessenger";

    /**
     * QQ支付宝扫码时携带的user agent信息
     */
    public static final String USER_AGENT_QQ = "QQ";
}
