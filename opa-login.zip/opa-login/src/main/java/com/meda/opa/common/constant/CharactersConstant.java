package com.meda.opa.common.constant;

/**
 * 字符常量
 *
 * @author Huangxiaodi
 * @date 2018/11/14
 */
public class CharactersConstant {

    /**
     * 回车占位符
     */
    public static final String ENTER_MARKER = "<Enter>";

    public static final String CHARSET_UTF8 = "UTF-8";

    public static final String COMMA = ",";
}
