package com.meda.opa.login.service.auth.impl;

import com.meda.opa.common.constant.CharactersConstant;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.common.constant.UserCenterConstant;
import com.meda.opa.common.enums.ResultCode;
import com.meda.opa.common.util.LogUtils;
import com.meda.opa.config.MinishowConfig;
import com.meda.opa.config.QQConfig;
import com.meda.opa.login.dto.LoginOrRegisterResult;
import com.meda.opa.login.vo.EmptyInfo;
import com.meda.opa.login.vo.ProductInfo;
import com.meda.opa.login.vo.UserRegisterReq;
import com.meda.opa.platform.qq.constant.QQErrorCode;
import com.meda.opa.platform.qq.service.QQService;
import com.meda.opa.platform.qq.vo.QqAccessToken;
import com.meda.opa.platform.qq.vo.QqOAuthToken;
import com.meda.opa.platform.qq.vo.QqUserInfo;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * QQ用户授权登录服务实现类
 *
 * @author Huangxiaodi
 * @date 2018/11/21.
 */
@Service("qqAuthService")
public class QQAuthServiceImpl extends AbstractAuthServiceImpl {

    private static Logger log = LoggerFactory.getLogger(QQAuthServiceImpl.class);

    @Autowired
    private QQService qqService;

    @Override
    public String getThirdPartyAuthoriseUrl(ProductInfo productInfo) {
        String arg = assembleQueryStringFromProductInfo(productInfo);
        String uri = QQConfig.AUTH_REDIRECT_URI.replace("MID", arg);
        try {
            // 回调地址必须encode
            uri = URLEncoder.encode(uri, CharactersConstant.CHARSET_UTF8);
        } catch (UnsupportedEncodingException e) {
            LogUtils.logErrorWithException(log, "扫码登录重定向-回调uri编码", LogConstant.RES_EXCEPTION, "", 0,
                    Integer.parseInt(productInfo.getMid()), "QQ扫码登录重定向回调uri编码【失败】", e);
        }
        // qq授权链接
        String url = QQConfig.AUTH_URL
                .replace("appId", QQConfig.APP_ID)
                .replace("redirectUri", uri);

        return url;
    }

    @Override
    public LoginOrRegisterResult getAuth(String code, String arg) {
        Assert.hasText(code, "code参数不能为空");
        Assert.hasText(arg, "arg参数不能为空");

        QqOAuthToken qqOAuthToken = qqService.getAccessTokenFromCode(code);
        if (qqOAuthToken == null || QQErrorCode.SUCCESS != qqOAuthToken.getErrCode()) {
            return new LoginOrRegisterResult(ResultCode.QQ_GET_ACCESS_TOKEN_FROM_CODE_FAIL.getCode());
        }

        QqAccessToken qqAccessToken = qqService.getPublicAccessToken();
        if (qqAccessToken == null || QQErrorCode.SUCCESS != qqAccessToken.getErrCode()) {
            return new LoginOrRegisterResult(ResultCode.QQ_GET_MP_ACCESS_TOKEN_FAIL.getCode());
        }

        QqUserInfo qqUserInfo = qqService.getUserInfo(qqAccessToken.getAccessToken(), qqOAuthToken.getOpenId());
        if (qqUserInfo == null) {
            return new LoginOrRegisterResult(ResultCode.QQ_GET_USERINFO_FAIL.getCode());
        }

        ProductInfo productInfo = setProductInfo(arg);
        productInfo.setInfo(new EmptyInfo());
        UserRegisterReq.QQUserInfo userInfo = setUserInfo(qqUserInfo);

        UserRegisterReq userRegisterReq = new UserRegisterReq();
        userRegisterReq.setProduct(productInfo);
        userRegisterReq.setUsrinfo(userInfo);
        userRegisterReq.setLoginId(qqOAuthToken.getOpenId());
        userRegisterReq.setType(UserCenterConstant.TYPE_QQ);
        userRegisterReq.setPwd(UserCenterConstant.PWD_NONE);

        Integer mid = Integer.parseInt(productInfo.getMid());
        // 调用用户中心注册登录接口
        LoginOrRegisterResult loginAndRegisterResult = loginOrRegisterFromUserCenter(userRegisterReq, mid);

        loginAndRegisterResult.setCouponId(productInfo.getCoupon_id());
        loginAndRegisterResult.setMid(mid);
        loginAndRegisterResult.setUnionId(qqOAuthToken.getUnionId());
        return loginAndRegisterResult;
    }

    /**
     * 根据QQ查询用户信息接口返回的用户信息vo封装为用户中心请求json的usrinfo节点
     *
     * @param qqUserInfo QQ查询用户信息接口返回的vo
     * @return
     */
    private UserRegisterReq.QQUserInfo setUserInfo(QqUserInfo qqUserInfo) {
        UserRegisterReq.QQUserInfo userInfo = new UserRegisterReq.QQUserInfo();
        userInfo.setBindQQ(qqUserInfo.getOpenId());
        userInfo.setCity(qqUserInfo.getCity());
        userInfo.setCountry(qqUserInfo.getCountry());
        userInfo.setEx(UserCenterConstant.EX_QQ);
        userInfo.setImageUrl(getHugeSizeHeadImgUrl(qqUserInfo.getHeadImgUrl()));
        userInfo.setName(qqUserInfo.getNickname());
        userInfo.setProvince(qqUserInfo.getProvince());
        userInfo.setSex(qqUserInfo.getSex());

        return userInfo;
    }

    /**
     * 将小头像处理为大头像
     *
     * @param headImgUrl 小头像原始url
     * @return
     */
    private String getHugeSizeHeadImgUrl(String headImgUrl) {
        if (StringUtils.isBlank(headImgUrl)) {
            return MinishowConfig.DEFAULT_HEADIMG_URL;
        }
        return headImgUrl.replaceFirst("(&s=)\\d+", "$1" + "0");
    }
}
