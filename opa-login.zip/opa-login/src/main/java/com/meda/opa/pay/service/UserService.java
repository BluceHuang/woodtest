package com.meda.opa.pay.service;

import com.meda.opa.pay.vo.UserIdentification;

/**
 * 用户服务接口
 *
 * @author Huangxiaodi
 * @date 2018/10/19
 */
public interface UserService {

    /**
     * 调用用户中心用户id查询接口，根据uid查询用户uno
     *
     * @param uid
     * @return
     */
    UserIdentification getUserIdentification(String uid);
}
