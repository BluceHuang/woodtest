package com.meda.opa.login.vo;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * 用户中心注册登录接口响应vo
 *
 * @author Huangxiaodi
 * @date 2018/11/21
 */
public class UserRegisterResp {

    private int status;

    @JSONField(name = "last_time")
    private String lastTime;

    private DataBody data;

    private ProductBody product;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getLastTime() {
        return lastTime;
    }

    public void setLastTime(String lastTime) {
        this.lastTime = lastTime;
    }

    public DataBody getData() {
        return data;
    }

    public void setData(DataBody data) {
        this.data = data;
    }

    public ProductBody getProduct() {
        return product;
    }

    public void setProduct(ProductBody product) {
        this.product = product;
    }

    @Override
    public String toString() {
        return "UserRegisterResp{" +
                "status='" + status + '\'' +
                ", lastTime='" + lastTime + '\'' +
                ", data=" + data +
                ", product=" + product +
                '}';
    }

    public static class DataBody {

        private String type;

        private String uid;

        private int uno;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getUid() {
            return uid;
        }

        public void setUid(String uid) {
            this.uid = uid;
        }

        public int getUno() {
            return uno;
        }

        public void setUno(int uno) {
            this.uno = uno;
        }

        @Override
        public String toString() {
            return "DataBody{" +
                    "type='" + type + '\'' +
                    ", uid='" + uid + '\'' +
                    ", uno=" + uno +
                    '}';
        }
    }

    public static class ProductBody {

        private int status;

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        @Override
        public String toString() {
            return "ProductBody{" +
                    "status=" + status +
                    '}';
        }
    }

}
