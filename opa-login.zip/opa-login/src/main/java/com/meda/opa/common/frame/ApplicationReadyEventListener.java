package com.meda.opa.common.frame;

import com.meda.opa.platform.alipay.service.impl.AliPayServiceImpl;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

/**
 * @author Huangxiaodi
 * @date 2018/11/27
 */
@Component
public class ApplicationReadyEventListener implements ApplicationListener<ApplicationReadyEvent> {
    @Override
    public void onApplicationEvent(ApplicationReadyEvent applicationReadyEvent) {
        // 初始化aliPayClient，使client变为单例
        AliPayServiceImpl.initAliPayClient();
    }
}
