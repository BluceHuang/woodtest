package com.meda.opa.pay.service.impl;

import com.meda.opa.common.constant.CharactersConstant;
import com.meda.opa.common.constant.HttpConstant;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.common.constant.WeChatConstant;
import com.meda.opa.common.enums.MinishowOtherRespCode;
import com.meda.opa.config.MinishowConfig;
import com.meda.opa.config.WeChatConfig;
import com.meda.opa.pay.service.CouponService;
import com.meda.opa.pay.service.PackageService;
import com.meda.opa.pay.vo.BuyRequest;
import com.meda.opa.pay.vo.coupon.ResponseInCoupon;
import com.meda.opa.pay.vo.user.RequestInCheckPayStatus;
import com.meda.opa.pay.vo.user.ResponseInCheckPayStatus;
import com.meda.opa.common.util.Base64Utils;
import com.meda.opa.common.util.HttpUtil;
import com.meda.opa.common.util.LogUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 套餐购买服务接口实现类
 *
 * @author Huangxiaodi
 * @date 2018/11/7
 */
@Service
public class PackageServiceImpl implements PackageService {

    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private CouponService couponService;

    @Override
    public String buildPackageBuyRedirectUrl(String uid, String uno, String mid, String unionId, String couponId) {
        StringBuffer toPackageBuyUrlBuffer = new StringBuffer(MinishowConfig.PACKAGE_BUY_URL);
        toPackageBuyUrlBuffer.append("&mid=");
        toPackageBuyUrlBuffer.append(mid);
        toPackageBuyUrlBuffer.append("&uid=");
        toPackageBuyUrlBuffer.append(uid);
        toPackageBuyUrlBuffer.append("&unionId=");
        toPackageBuyUrlBuffer.append(unionId);
        toPackageBuyUrlBuffer.append("&uno=");
        toPackageBuyUrlBuffer.append(uno);
        toPackageBuyUrlBuffer.append("&cmd=");
        toPackageBuyUrlBuffer.append(MinishowConfig.PACKAGE_BUY_CMD);
        toPackageBuyUrlBuffer.append("&buydomain=");
        toPackageBuyUrlBuffer.append(MinishowConfig.SERVER_DOMAIN);

        if (StringUtils.isNotBlank(couponId)) {
            ResponseInCoupon responseInCouponQuery = couponService.getCouponInfoById(couponId);
            ResponseInCoupon.DataBody dataBody = responseInCouponQuery.getData();

            toPackageBuyUrlBuffer.append("&status=");
            toPackageBuyUrlBuffer.append(dataBody.getCouponsStatus());
            toPackageBuyUrlBuffer.append("&couponId=");
            toPackageBuyUrlBuffer.append(dataBody.getCouponsId());
            toPackageBuyUrlBuffer.append("&type=");
            toPackageBuyUrlBuffer.append(dataBody.getFreeType() == 0 ? "" : dataBody.getFreeType());
            toPackageBuyUrlBuffer.append("&duration=");
            toPackageBuyUrlBuffer.append(dataBody.getFreeDuration() == 0 ? "" : dataBody.getFreeDuration());
        }
        String encodeToPackageBuyUrl = Base64Utils.encode(toPackageBuyUrlBuffer.toString());
        String weChatRedirectUrl = MinishowConfig.PACKAGE_BUY_REDIRECT_URL.replace("targetStr", encodeToPackageBuyUrl);

        String packageBuyRedirectUrl = WeChatConfig.AUTH_URL
                .replace("appId", WeChatConfig.PAY_APP_ID)
                .replace("redirectUri", weChatRedirectUrl)
                .replace("stateStr", "minishow_buy")
                .replace("scopeStr", WeChatConstant.SCOPE_BASE);

        return packageBuyRedirectUrl;
    }

    @Override
    public ResponseInCheckPayStatus checkPayStatus(int uno, String uid, int mid, int packageId, int costMode, int timeSeconds, int source, int useCoupon) {
        RequestInCheckPayStatus requestEntity = new RequestInCheckPayStatus(uno, uid, packageId, costMode, timeSeconds, source, useCoupon);
        LogUtils.logDebug(log, "购买套餐资格验证", LogConstant.RES_NONE, uid, uno, mid,
                "访问用户购买套餐资格验证接口，请求内容为：" + requestEntity);
        try {
            ResponseInCheckPayStatus responseEntity = HttpUtil.sendJsonDataAndGetResponseEntity(false, MinishowConfig.TELL_ACCOUNT_SELF_STATUS_URL,
                    HttpConstant.REQUEST_METHOD_PUT,
                    requestEntity, ResponseInCheckPayStatus.class);
            if (MinishowOtherRespCode.SUCCESS.getResCode() == responseEntity.getStatus()) {
                LogUtils.logDebug(log, "购买套餐资格验证", LogConstant.RES_SUCCESS, uid, uno, mid,
                        "用户购买套餐资格验证【通过】，响应内容为：" + responseEntity);
                return responseEntity;
            } else {
                LogUtils.logError(log, "购买套餐资格验证", LogConstant.RES_FAIL, uid, uno, mid,
                        "用户购买套餐资格验证【失败】，响应内容为：" + responseEntity);
                return null;
            }
        } catch (Exception e) {
            LogUtils.logErrorWithException(log, "购买套餐资格验证", LogConstant.RES_EXCEPTION, uid, uno, mid,
                    "访问用户购买套餐资格验证接口【异常】", e);
            return null;
        }
    }
}
