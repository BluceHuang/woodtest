package com.meda.opa.pay.service.impl;

import com.meda.opa.common.constant.HttpConstant;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.common.enums.CouponResponseCode;
import com.meda.opa.common.enums.CouponStatus;
import com.meda.opa.config.SystemConfig;
import com.meda.opa.pay.service.CouponService;
import com.meda.opa.pay.vo.CouponRequest;
import com.meda.opa.pay.vo.coupon.RequestInCoupon;
import com.meda.opa.pay.vo.coupon.ResponseInCoupon;
import com.meda.opa.common.util.DateUtils;
import com.meda.opa.common.util.HttpUtil;
import com.meda.opa.common.util.LogUtils;
import com.meda.opa.common.util.RandomUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;


/**
 * 优惠券服务接口实现类
 *
 * @author Huangxiaodi
 * @date 2018/10/23
 */
@Service
public class CouponServiceImpl implements CouponService {

    private static final Logger log = LoggerFactory.getLogger(CouponServiceImpl.class);

    @Override
    public ResponseInCoupon getCouponInfoById(String couponId) {
        CouponRequest couponRequest = new CouponRequest();
        couponRequest.setCoupon_id(couponId);
        return this.requestToCouponServer(couponRequest, "query_coupons");
    }

    @Override
    public ResponseInCoupon useCoupon(CouponRequest couponRequest) {
        return this.requestToCouponServer(couponRequest, "use_coupons");
    }

    /**
     * 请求优惠券服务器
     *
     * @param couponRequest 请求vo
     * @param cmd           指令
     * @return
     */
    private ResponseInCoupon requestToCouponServer(CouponRequest couponRequest, String cmd) {
        // 构建请求实体
        RequestInCoupon requestEntity = buildRequestEntity(couponRequest, cmd);

        LogUtils.logDebug(log, cmd, LogConstant.RES_NONE, couponRequest.getUid(), couponRequest.getUno() == null ? 0 : couponRequest.getUno(),
                couponRequest.getMid() == null ? 0 : couponRequest.getMid(),
                "调用优惠券" + cmd + "接口，请求内容为：" + requestEntity);
        ResponseInCoupon responseEntity = null;
        try {
            responseEntity = HttpUtil.sendJsonDataAndGetResponseEntity(false, SystemConfig.COUPON_URL, HttpConstant.REQUEST_METHOD_PUT,
                    requestEntity, ResponseInCoupon.class);
            if (CouponResponseCode.SUCCESS.getResCode() == responseEntity.getStatus()) {
                LogUtils.logDebug(log, cmd, LogConstant.RES_SUCCESS, couponRequest.getUid(), couponRequest.getUno() == null ? 0 : couponRequest.getUno(),
                        couponRequest.getMid() == null ? 0 : couponRequest.getMid(),
                        "调用优惠券" + cmd + "接口【成功】，响应内容为：" + responseEntity);
                return responseEntity;
            } else {
                LogUtils.logError(log, cmd, LogConstant.RES_FAIL, couponRequest.getUid(), couponRequest.getUno() == null ? 0 : couponRequest.getUno(),
                        couponRequest.getMid() == null ? 0 : couponRequest.getMid(),
                        "调用优惠券" + cmd + "接口返回【错误】：" + responseEntity);
                responseEntity.getData().setCouponsStatus(CouponStatus.ERROR.getCode());
                return responseEntity;
            }

        } catch (Exception e) {
            LogUtils.logErrorWithException(log, cmd, LogConstant.RES_EXCEPTION, couponRequest.getUid(), couponRequest.getUno() == null ? 0 : couponRequest.getUno(),
                    couponRequest.getMid() == null ? 0 : couponRequest.getMid(),
                    "访问优惠券" + cmd + "接口【异常】", e);
            return buildExceptionResponseEntity(CouponStatus.ERROR.getCode());
        }
    }

    /**
     * 构建请求体
     *
     * @param couponRequest 请求vo
     * @param cmd           指令
     * @return
     */
    private RequestInCoupon buildRequestEntity(CouponRequest couponRequest, String cmd) {
        String randomNumStr = RandomUtils.getRandomNumStr(4);
        String sequenceNum = DateUtils.getDateStr(null, DateUtils.NO_MILLIS_PIPELINE_FORMAT) + randomNumStr;

        RequestInCoupon requestEntity = new RequestInCoupon();
        requestEntity.setSeqNo(sequenceNum);
        requestEntity.setCmd(cmd);

        RequestInCoupon.DataBody dataBody = new RequestInCoupon.DataBody(couponRequest.getCoupon_id(), couponRequest.getOpenid(),
                couponRequest.getUid(), couponRequest.getUno(), couponRequest.getMid(), couponRequest.getSource(),
                couponRequest.getCost_mode(), couponRequest.getTime_seconds());
        requestEntity.setData(dataBody);
        return requestEntity;
    }

    /**
     * 构建异常响应体
     *
     * @param code 响应码
     * @return
     */
    private ResponseInCoupon buildExceptionResponseEntity(int code) {
        ResponseInCoupon errorResponseEntity = new ResponseInCoupon();
        ResponseInCoupon.DataBody respDataBody = new ResponseInCoupon.DataBody();
        respDataBody.setCouponsStatus(code);
        errorResponseEntity.setData(respDataBody);
        return errorResponseEntity;
    }
}
