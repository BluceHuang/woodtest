package com.meda.opa.pay.vo.coupon;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * 优惠券服务请求实体
 *
 * @author Huangxiaodi
 * @date 2018/10/23
 */
public class RequestInCoupon {

    @JSONField(name = "seqno")
    private String seqNo;

    private String cmd;

    private DataBody data;

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public DataBody getData() {
        return data;
    }

    public void setData(DataBody data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "RequestInCoupon{" +
                "seqNo='" + seqNo + '\'' +
                ", cmd='" + cmd + '\'' +
                ", data=" + data +
                '}';
    }

    public static class DataBody {

        @JSONField(name = "coupons_id")
        private String couponsId;

        @JSONField(name = "openid")
        private String openId;

        private String uid;

        private Integer uno;

        private Integer mid;

        private Integer source;

        @JSONField(name = "cost_mode")
        private Integer costMode;

        @JSONField(name = "time_seconds")
        private Integer timeSeconds;

        public DataBody() {

        }

        public DataBody(String couponsId, String openid, String uid, Integer uno, Integer mid, Integer source, Integer costMode, Integer timeSeconds) {
            this.couponsId = couponsId;
            this.openId = openid;
            this.uid = uid;
            this.uno = uno;
            this.mid = mid;
            this.source = source;
            this.costMode = costMode;
            this.timeSeconds = timeSeconds;
        }

        public String getCouponsId() {
            return couponsId;
        }

        public void setCouponsId(String couponsId) {
            this.couponsId = couponsId;
        }

        public String getOpenId() {
            return openId;
        }

        public void setOpenId(String openId) {
            this.openId = openId;
        }

        public String getUid() {
            return uid;
        }

        public void setUid(String uid) {
            this.uid = uid;
        }

        public Integer getUno() {
            return uno;
        }

        public void setUno(Integer uno) {
            this.uno = uno;
        }

        public Integer getMid() {
            return mid;
        }

        public void setMid(Integer mid) {
            this.mid = mid;
        }

        public Integer getSource() {
            return source;
        }

        public void setSource(Integer source) {
            this.source = source;
        }

        public Integer getCostMode() {
            return costMode;
        }

        public void setCostMode(Integer costMode) {
            this.costMode = costMode;
        }

        public Integer getTimeSeconds() {
            return timeSeconds;
        }

        public void setTimeSeconds(Integer timeSeconds) {
            this.timeSeconds = timeSeconds;
        }

        @Override
        public String toString() {
            return "DataBody{" +
                    "couponsId='" + couponsId + '\'' +
                    ", openId='" + openId + '\'' +
                    ", uid='" + uid + '\'' +
                    ", uno=" + uno +
                    ", mid=" + mid +
                    ", source=" + source +
                    ", costMode=" + costMode +
                    ", timeSeconds=" + timeSeconds +
                    '}';
        }
    }
}
