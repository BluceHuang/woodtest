package com.meda.opa.common.constant;

/**
 * log常量类
 *
 * @author Huangxiaodi
 * @date 2018/11/13
 */
public class LogConstant {

    /**
     * 业务失败
     */
    public static final String RES_FAIL = "失败";

    /**
     * 业务成功
     */
    public static final String RES_SUCCESS = "成功";

    /**
     * 系统异常
     */
    public static final String RES_EXCEPTION = "系统异常";

    /**
     * 无
     */
    public static final String RES_NONE = "无";
}
