package com.meda.opa.config;

import com.meda.opa.common.enums.ResultCode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * minishow配置常量类
 *
 * @author Huangxiaodi
 * @date 2018/11/14
 */
@Component
public class MinishowConfig {

    /**
     * minishow通用错误页面
     */
    public static String COMMON_ERROR_URL;

    /**
     * 点歌页面重定向，参数错误时指向的页面
     */
    public static String ORDER_SONG_REDIRECT_PARAM_ERROR_URL;

    /**
     * 点歌页面重定向，微信获取支付accessToken失败时指向的页面
     */
    public static String WECHAT_GET_PAY_ACCESS_TOKEN_ERROR_URL;

    /**
     * 系统异常时指向的页面
     */
    public static String SYSTEM_ERROR_URL;

    /**
     * minishow登录注册失败
     */
    public static String LOGIN_FAIL_URL;

    /**
     * minishow系统繁忙时指向的页面
     */
    public static String SYSTEM_BUSY_URL;

    /**
     * 无效客户端指向的错误页面
     */
    public static String INVALID_USER_AGENT_ERROR_URL;

    /**
     * minishow appName
     */
    public static String APP_NAME;

    /**
     * minishow机器界限版本号
     */
    public static String MACHINE_CAPI_VERSION;

    /**
     * 套餐购买重定向url
     */
    public static String PACKAGE_BUY_REDIRECT_URL;

    /**
     * 套餐购买url
     */
    public static String PACKAGE_BUY_URL;

    /**
     * 套餐购买指令
     */
    public static String PACKAGE_BUY_CMD;

    /**
     * minishow公众号服务使用域名
     */
    public static String SERVER_DOMAIN;

    /**
     * minishow补充服务 TELL_ACCOUNT_SELF_STATUS服务url
     */
    public static String TELL_ACCOUNT_SELF_STATUS_URL;

    /**
     * 默认用户头像
     */
    public static String DEFAULT_HEADIMG_URL;

    @Value("${minishow.common.error.url}")
    public void setCommonErrorUrl(String commonErrorUrl) {
        COMMON_ERROR_URL = commonErrorUrl;
        ORDER_SONG_REDIRECT_PARAM_ERROR_URL = commonErrorUrl.replace("CODE", ResultCode.ORDER_SONG_REDIRECT_PARAM_ERROR.getCode());
        WECHAT_GET_PAY_ACCESS_TOKEN_ERROR_URL = commonErrorUrl.replace("CODE", ResultCode.WECHAT_GET_PAY_ACCESS_TOKEN_FAIL.getCode());
        SYSTEM_ERROR_URL = commonErrorUrl.replace("CODE", ResultCode.SYSTEM_EXCEPTION.getCode());
        SYSTEM_BUSY_URL = commonErrorUrl.replace("CODE", ResultCode.BUSY.getCode());
    }

    @Value("${minishow.login.fail.url}")
    public void setLoginFailUrl(String loginFailUrl) {
        LOGIN_FAIL_URL = loginFailUrl;
        INVALID_USER_AGENT_ERROR_URL = loginFailUrl.replace("CODE", ResultCode.INVALID_USER_AGENT.getCode());
    }

    @Value("${minishow.appname}")
    public void setAppname(String appname) {
        APP_NAME = appname;
    }

    @Value("${minishow.machine.capi_version}")
    public void setMachineCapiVersion(String machineCapiVersion) {
        MACHINE_CAPI_VERSION = machineCapiVersion;
    }

    @Value("${minishow.package_buy_redirect.url}")
    public void setPackageBuyRedirectUrl(String packageBuyRedirectUrl) {
        PACKAGE_BUY_REDIRECT_URL = packageBuyRedirectUrl;
    }

    @Value("${minishow.package.buy.url}")
    public void setPackageBuyUrl(String packageBuyUrl) {
        PACKAGE_BUY_URL = packageBuyUrl;
    }

    @Value("${minishow.package.buy.cmd}")
    public void setPackageBuyCmd(String packageBuyCmd) {
        PACKAGE_BUY_CMD = packageBuyCmd;
    }

    @Value("${minishow.server.domain}")
    public void setServerDomain(String serverDomain) {
        SERVER_DOMAIN = serverDomain;
    }

    @Value("${minishow.tell_account_self_status.url}")
    public void setTellAccountSelfStatusUrl(String tellAccountSelfStatusUrl) {
        TELL_ACCOUNT_SELF_STATUS_URL = tellAccountSelfStatusUrl;
    }

    @Value("${minishow.default.headImg.url}")
    public void setDefaultHeadimgUrl(String defaultHeadimgUrl) {
        DEFAULT_HEADIMG_URL = defaultHeadimgUrl;
    }
}
