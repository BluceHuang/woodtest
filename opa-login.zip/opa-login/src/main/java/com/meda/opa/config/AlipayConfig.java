package com.meda.opa.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 支付宝平台配置类
 *
 * @author Huangxiaodi
 * @date 2018/11/23
 */
@Component
public class AlipayConfig {

    /**
     * 授权登录后回调url
     */
    public static String AUTH_REDIRECT_URI;

    /**
     * 授权登录url
     */
    public static String AUTH_URL;

    /**
     * 支付网关
     */
    public static String PAY_GATEWAY;

    /**
     * appId
     */
    public static String APP_ID;

    /**
     * 商户应用私钥
     */
    public static String PAY_PRIVATE_KEY;

    /**
     * 商户应用公钥
     */
    public static String PAY_PUBLIC_KEY;

    @Value("${alipay.authorize.redirect.uri}")
    public void setAuthRedirectUri(String authRedirectUri) {
        AUTH_REDIRECT_URI = authRedirectUri;
    }

    @Value("${alipay.authorize.url}")
    public void setAuthUrl(String authUrl) {
        AUTH_URL = authUrl;
    }

    @Value("${alipay.gateway}")
    public void setPayGateway(String payGateway) {
        PAY_GATEWAY = payGateway;
    }

    @Value("${alipay.appId}")
    public void setAppId(String appId) {
        APP_ID = appId;
    }

    @Value("${alipay.private.key}")
    public void setPayPrivateKey(String payPrivateKey) {
        PAY_PRIVATE_KEY = payPrivateKey;
    }

    @Value("${alipay.public.key}")
    public void setPayPublicKey(String payPublicKey) {
        PAY_PUBLIC_KEY = payPublicKey;
    }
}
