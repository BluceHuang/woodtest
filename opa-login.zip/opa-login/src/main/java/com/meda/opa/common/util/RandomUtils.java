package com.meda.opa.common.util;

import java.util.concurrent.ThreadLocalRandom;

/**
 * 随机工具类
 *
 * @author Huangxiaodi
 * @date 2018/10/25
 */
public class RandomUtils {

    private static final String[] MIXED_SEEDS = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "z", "y", "x", "w", "v",
            "u", "t", "s", "r", "q", "p", "o", "n", "m", "l", "k", "j", "i", "h", "g", "f", "e", "d", "c", "b", "a"};

    /**
     * 根据给定长度生成随机数字符串
     *
     * @param length
     * @return
     */
    public static String getRandomNumStr(int length) {
        StringBuffer randomNumStr = new StringBuffer();
        for (int i = 0; i < length; i++) {
            randomNumStr.append(ThreadLocalRandom.current().nextInt(10));
        }
        return randomNumStr.toString();
    }

    /**
     * 根据给定的长度生成随机混合字符串
     *
     * @param length
     * @return
     */
    public static String getRandomMixedStr(int length) {
        StringBuffer randomNumStr = new StringBuffer();
        int seedsLength = MIXED_SEEDS.length;
        for (int i = 0; i < length; i++) {
            int index = ThreadLocalRandom.current().nextInt(seedsLength);
            randomNumStr.append(MIXED_SEEDS[index]);
        }
        return randomNumStr.toString();
    }
}
