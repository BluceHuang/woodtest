package com.meda.opa.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 系统配置
 *
 * @author Huangxiaodi
 * @date 2018/11/12.
 */
@Component
public class SystemConfig {

    /**
     * 用户中心注册登录接口
     */
    public static String REGISTER_AND_LOGIN_URL;

    /**
     * 优惠券服务url
     */
    public static String COUPON_URL;

    /**
     * minik机器信息查询服务url
     */
    public static String GET_MACHINE_INFO_URL;

    /**
     * 用户中心uno查询接口
     */
    public static String UNO_QUERY_URL;

    @Value("${user.center.register.login.url}")
    public void setRegisterAndLoginUrl(String registerAndLoginUrl) {
        REGISTER_AND_LOGIN_URL = registerAndLoginUrl;
    }

    @Value("${coupon.url}")
    public void setCouponUrl(String couponUrl) {
        COUPON_URL = couponUrl;
    }

    @Value("${get_machine_info.url}")
    public void setGetMachineInfoUrl(String getMachineInfoUrl) {
        GET_MACHINE_INFO_URL = getMachineInfoUrl;
    }

    @Value("${user.center.uno.query.url}")
    public void setUnoQueryUrl(String unoQueryUrl) {
        UNO_QUERY_URL = unoQueryUrl;
    }
}
