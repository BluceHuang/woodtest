package com.meda.opa.platform.wechat.service.impl;

import com.meda.opa.common.constant.HttpConstant;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.config.WeChatConfig;
import com.meda.opa.platform.wechat.service.WeChatService;
import com.meda.opa.platform.wechat.vo.OAuthToken;
import com.meda.opa.platform.wechat.vo.ResponseInGetUserinfo;
import com.meda.opa.common.util.HttpUtil;
import com.meda.opa.common.util.LogUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * 微信服务接口实现类
 *
 * @author Huangxiaodi
 * @date 2018/10/22
 */
@Service
public class WeChatServiceImpl implements WeChatService {

    private static final Logger log = LoggerFactory.getLogger(WeChatServiceImpl.class);

    @Override
    public OAuthToken getAccessToken(String appId, String appSecret, String code) {
        String url = WeChatConfig.ACCESS_TOKEN_UNFOLLOW_URL.replace("appId", appId)
                .replace("appSecret", appSecret)
                .replace("CODE", code);

        try {
            OAuthToken oAuthToken = HttpUtil.sendWithoutDataAndGetResponseEntity(true, url, HttpConstant.REQUEST_METHOD_GET, OAuthToken.class);
            if (StringUtils.isBlank(oAuthToken.getErrMsg())) {
                LogUtils.logDebug(log, "微信获取网页授权", LogConstant.RES_SUCCESS, "", 0, 0,
                        "访问微信获取网页授权access_token接口【成功】！响应内容为：" + oAuthToken);
            } else {
                LogUtils.logError(log, "微信获取网页授权", LogConstant.RES_FAIL, "", 0, 0,
                        "访问微信获取网页授权access_token接口返回【错误】，响应内容为：" + oAuthToken);
            }
            return oAuthToken;
        } catch (Exception e) {
            LogUtils.logErrorWithException(log, "微信获取网页授权", LogConstant.RES_EXCEPTION, "", 0, 0,
                    "访问微信获取网页授权access_token接口【异常】", e);
            return null;
        }
    }

    @Override
    public ResponseInGetUserinfo getUserinfo(String accessToken, String openId) {
        String url = WeChatConfig.USERINFO_UNFOLLOW_URL
                .replace("ACCESS_TOKEN", accessToken)
                .replace("OPENID", openId);

        try {
            ResponseInGetUserinfo responseInGetUserinfo = HttpUtil.sendWithoutDataAndGetResponseEntity(true, url,
                    HttpConstant.REQUEST_METHOD_GET, ResponseInGetUserinfo.class);
            if (StringUtils.isBlank(responseInGetUserinfo.getErrCode())) {
                LogUtils.logDebug(log, "微信拉取用户信息", LogConstant.RES_SUCCESS, "", 0, 0,
                        "访问微信拉取用户信息接口【成功】，响应内容为：" + responseInGetUserinfo);
                return responseInGetUserinfo;
            } else {
                LogUtils.logError(log, "微信拉取用户信息", LogConstant.RES_FAIL, "", 0, 0,
                        "访问微信拉取用户信息接口返回【错误】：" + responseInGetUserinfo);
                return null;
            }
        } catch (Exception e) {
            LogUtils.logErrorWithException(log, "微信拉取用户信息", LogConstant.RES_EXCEPTION, "", 0, 0,
                    "访问微信拉取用户信息接口【异常】", e);
            return null;
        }
    }
}
