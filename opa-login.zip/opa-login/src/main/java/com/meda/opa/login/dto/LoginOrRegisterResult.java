package com.meda.opa.login.dto;

/**
 * 用户中心注册或登录结果
 *
 * @author Huangxiaodi
 * @date 2018/11/21
 */
public class LoginOrRegisterResult {

    private String responseCode;

    private String uid;

    private Integer uno;

    private Integer mid;

    private String unionId;

    private String couponId;

    public LoginOrRegisterResult() {

    }

    public LoginOrRegisterResult(String responseCode) {
        this.responseCode = responseCode;
    }

    public LoginOrRegisterResult(String responseCode, String uid, Integer uno) {
        this.responseCode = responseCode;
        this.uid = uid;
        this.uno = uno;
    }

    public LoginOrRegisterResult(String responseCode, String uid, Integer uno, Integer mid, String unionId, String couponId) {
        this.responseCode = responseCode;
        this.uid = uid;
        this.uno = uno;
        this.mid = mid;
        this.unionId = unionId;
        this.couponId = couponId;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public Integer getUno() {
        return uno;
    }

    public void setUno(Integer uno) {
        this.uno = uno;
    }

    public Integer getMid() {
        return mid;
    }

    public void setMid(Integer mid) {
        this.mid = mid;
    }

    public String getUnionId() {
        return unionId;
    }

    public void setUnionId(String unionId) {
        this.unionId = unionId;
    }

    public String getCouponId() {
        return couponId;
    }

    public void setCouponId(String couponId) {
        this.couponId = couponId;
    }

    @Override
    public String toString() {
        return "LoginAndRegisterResult{" +
                "responseCode='" + responseCode + '\'' +
                ", uid='" + uid + '\'' +
                ", uno=" + uno +
                ", mid=" + mid +
                ", unionId='" + unionId + '\'' +
                ", couponId='" + couponId + '\'' +
                '}';
    }
}
