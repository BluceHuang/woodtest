package com.meda.opa;

import com.meda.opa.common.constant.HttpConstant;
import com.meda.opa.common.constant.LogConstant;
import com.meda.opa.common.enums.ResultCode;
import com.meda.opa.common.util.LogUtils;
import com.meda.opa.config.MinishowConfig;
import com.meda.opa.pay.vo.ResponseEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletRequest;

/**
 * 全局异常处理器
 *
 * @author Huangxiaodi
 * @date 2018/11/14
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(value = Exception.class)
    public Object defaultErrorHandler(HttpServletRequest req, Exception e) throws Exception {
        LogUtils.logErrorWithException(log, "", LogConstant.RES_EXCEPTION, "", 0, 0, "系统异常：" + e.getMessage(), e);
        // 使用HttpServletRequest中的header检测请求是否为ajax, 如果是ajax则返回json, 如果为非ajax则返回view
        String acceptHeader = req.getHeader(HttpConstant.HEADER_ACCEPT) == null ? "" : req.getHeader(HttpConstant.HEADER_ACCEPT);
        String xRequestedWith = req.getHeader(HttpConstant.HEADER_X_REQUESTED_WITH) == null ? "" : req.getHeader(HttpConstant.HEADER_X_REQUESTED_WITH);
        if (acceptHeader.contains(HttpConstant.CONTENT_TYPE_JSON)
                || HttpConstant.REQUEST_TYPE_XML_HTTP_REQUEST.equalsIgnoreCase(xRequestedWith)) {
            return new ResponseEntity<>(false, ResultCode.SYSTEM_EXCEPTION.getCode(), ResultCode.SYSTEM_EXCEPTION.getDescription());
        } else {
            return new RedirectView(MinishowConfig.SYSTEM_ERROR_URL);
        }
    }
}
